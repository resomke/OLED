Task3_U8G2.hex
  Keil MDK-ARM 编译版（ARM Compiler 6.7），Intel HEX，起始地址 0x08000000。
  本机 Keil 5.24a + DFP 2.2.0 实测：0 Error(s), 0 Warning(s)。
  STM32CubeProgrammer / Keil / FlyMcu 直接选择此文件。

Task3_U8G2.bin
  Keil 版原始二进制，烧录时起始地址必须设为 0x08000000。

Task3_U8G2_gcc.hex / Task3_U8G2_gcc.bin
  GNU Arm GCC 14.2 编译版，功能相同，作为没有 Keil 时的备份。
  Keil 版约 30.3 KB Flash，GCC 版约 26.4 KB Flash。

芯片：STM32F103C8T6（64 KB Flash，20 KB RAM）
接线：OLED SCL=PB6，SDA=PB7，VCC=3.3V，GND=GND
昵称：ReSm0ke
学号：632407030413
