/**
  ******************************************************************************
  * @file    u8g2_port.c
  * @brief   U8g2 -> STM32 HAL I2C1(PB6/PB7) 的字节回调。
  *
  * 说明：
  *   U8g2 的 SSD1306 I2C 协议会在数据前面自动加 0x00(命令) 或 0x40(数据)，
  *   所以这里的 BYTE_SEND 直接把整段 buffer 发给 OLED 即可。
  ******************************************************************************
  */
#include "u8g2_port.h"
#include "app_config.h"
#include "bsp_i2c.h"
#include "stm32f1xx_hal.h"
#include <string.h>

u8g2_t u8g2;

static uint8_t s_addr8 = (uint8_t)(OLED_I2C_ADDR << 1);
static bool s_found;
static uint8_t s_u8g2_buffer[1024];

/* U8g2 会把控制字节(0x00/0x40)和数据分两次 SEND 回调发来，
 * 但 SSD1306 要求它们在同一次 I2C 传输里。所以这里先缓存，
 * 到 END_TRANSFER 再一次性发出。 */
static uint8_t s_i2c_buf[512];
static uint16_t s_i2c_len;
static bool s_i2c_active;

static uint8_t u8x8_byte_stm32_hw_i2c(u8x8_t *u8x8, uint8_t msg,
                                       uint8_t arg_int, void *arg_ptr)
{
    (void)u8x8;

    switch (msg)
    {
        case U8X8_MSG_BYTE_START_TRANSFER:
            s_i2c_len = 0U;
            s_i2c_active = true;
            break;

        case U8X8_MSG_BYTE_SEND:
            if (!s_found || !s_i2c_active)
            {
                return 0;
            }
            if ((uint32_t)s_i2c_len + arg_int > sizeof(s_i2c_buf))
            {
                return 0;
            }
            memcpy(&s_i2c_buf[s_i2c_len], arg_ptr, arg_int);
            s_i2c_len = (uint16_t)(s_i2c_len + arg_int);
            break;

        case U8X8_MSG_BYTE_END_TRANSFER:
            s_i2c_active = false;
            if (!s_found || (s_i2c_len == 0U))
            {
                break;
            }
            if (HAL_I2C_Master_Transmit(&hi2c1, s_addr8, s_i2c_buf,
                                        s_i2c_len, 100) != HAL_OK)
            {
                return 0;
            }
            break;

        case U8X8_MSG_BYTE_INIT:
        case U8X8_MSG_BYTE_SET_DC:
            break;

        default:
            return 0;
    }

    return 1;
}

static uint8_t u8x8_gpio_and_delay_stm32(u8x8_t *u8x8, uint8_t msg,
                                         uint8_t arg_int, void *arg_ptr)
{
    (void)arg_ptr;

    switch (msg)
    {
        case U8X8_MSG_GPIO_AND_DELAY_INIT:
            break;

        case U8X8_MSG_DELAY_MILLI:
            HAL_Delay(arg_int);
            break;

        case U8X8_MSG_DELAY_10MICRO:
            for (volatile uint32_t i = 0; i < (uint32_t)arg_int * 720U; ++i)
            {
                __NOP();
            }
            break;

        case U8X8_MSG_DELAY_100NANO:
        case U8X8_MSG_DELAY_NANO:
        case U8X8_MSG_DELAY_I2C:
            break;

        default:
            u8x8_SetGPIOResult(u8x8, 1);
            break;
    }

    return 1;
}

bool u8g2_port_init(void)
{
    s_found = false;

    if (bsp_i2c_probe(OLED_I2C_ADDR))
    {
        s_addr8 = (uint8_t)(OLED_I2C_ADDR << 1);
        s_found = true;
    }
    else if (bsp_i2c_probe(OLED_I2C_ADDR_ALT))
    {
        s_addr8 = (uint8_t)(OLED_I2C_ADDR_ALT << 1);
        s_found = true;
    }

    if (!s_found)
    {
        /* 没找到屏幕时顺手恢复一次 I2C，避免总线被拉死后一直重试失败 */
        bsp_i2c_recover();
        return false;
    }

    /* 只保留 SSD1306 128x64 + 全屏 1 KB 缓冲，避免把整包 U8g2 都链进来 */
    u8g2_SetupDisplay(&u8g2, u8x8_d_ssd1306_128x64_noname,
                      u8x8_cad_ssd13xx_fast_i2c,
                      u8x8_byte_stm32_hw_i2c,
                      u8x8_gpio_and_delay_stm32);
    u8g2_SetupBuffer(&u8g2, s_u8g2_buffer, 8,
                     u8g2_ll_hvline_vertical_top_lsb, U8G2_R0);
    u8x8_SetI2CAddress(&u8g2.u8x8, s_addr8);

    u8g2_InitDisplay(&u8g2);
    u8g2_SetPowerSave(&u8g2, 0);
    u8g2_ClearBuffer(&u8g2);
    u8g2_SendBuffer(&u8g2);

    return true;
}

void u8g2_port_send(void)
{
    if (s_found)
    {
        u8g2_SendBuffer(&u8g2);
    }
}

uint8_t u8g2_port_addr7(void)
{
    return s_found ? (uint8_t)(s_addr8 >> 1) : 0U;
}
