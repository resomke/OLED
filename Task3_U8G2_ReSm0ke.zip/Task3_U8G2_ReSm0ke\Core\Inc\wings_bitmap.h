/**
  ******************************************************************************
  * @file    wings_bitmap.h
  * @brief   自由之翼风格 96x48 动画帧（XBM，4 帧）。
  *          由 tools/make_wings.py 自动生成。
  ******************************************************************************
  */
#ifndef WINGS_BITMAP_H
#define WINGS_BITMAP_H

#include <stdint.h>

#define WINGS_WIDTH   96U
#define WINGS_HEIGHT  48U
#define WINGS_FRAMES  4U

extern const uint8_t wings_frames[WINGS_FRAMES][WINGS_WIDTH * WINGS_HEIGHT / 8U];

#endif /* WINGS_BITMAP_H */
