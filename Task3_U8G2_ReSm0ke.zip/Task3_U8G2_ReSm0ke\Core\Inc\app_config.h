/**
  ******************************************************************************
  * @file    app_config.h
  * @brief   任务三：U8g2 + SSD1306 的个性化配置。
  ******************************************************************************
  */
#ifndef APP_CONFIG_H
#define APP_CONFIG_H

#define NICKNAME                "ReSm0ke"
#define STUDENT_ID              "632407030413"
#define SCHOOL_LINE             "CQJTU IOT205"

/* 横向跑马灯内容：可以任意加长，程序会循环拼接 */
#define HORIZONTAL_TEXT         "ReSm0ke  *  632407030413  *  CQJTU IOT205  *  Wings of Freedom  *  "

/* OLED 7 位地址，常见 0x3C；少数模块 0x3D */
#define OLED_I2C_ADDR           0x3CU
#define OLED_I2C_ADDR_ALT       0x3DU

/* 页面停留时间（ms） */
#define PAGE_DEMO_MS            5000U
#define PAGE_PROFILE_MS         5000U
#define PAGE_VSCROLL_MS         12000U
#define PAGE_HSCROLL_MS         12000U
#define PAGE_WINGS_MS           12000U

/* 动画帧周期（ms） */
#define APP_FRAME_MS            40U

#define APP_USE_KEY_PA0         1
#define APP_USE_UART_LOG        1

#endif /* APP_CONFIG_H */
