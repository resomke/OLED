/**
  ******************************************************************************
  * @file    u8g2_port.h
  * @brief   U8g2 的 STM32 HAL I2C 移植层。
  ******************************************************************************
  */
#ifndef U8G2_PORT_H
#define U8G2_PORT_H

#include "u8g2.h"
#include <stdbool.h>
#include <stdint.h>

extern u8g2_t u8g2;

/* 探测 0x3C/0x3D，初始化 U8g2 和 SSD1306。 */
bool u8g2_port_init(void);

/* 把 U8g2 的 1 KB 显存发送到 OLED。 */
void u8g2_port_send(void);

/* 当前 OLED 的 7 位地址；未找到返回 0。 */
uint8_t u8g2_port_addr7(void);

#endif /* U8G2_PORT_H */
