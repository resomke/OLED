#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成“自由之翼”风格的点阵动画帧（96x48，4 帧）。

说明：这是一个受《进击的巨人》自由之翼启发的简化 fan-art 图案，
不是官方素材；用 1-bit 点阵重新绘制，适合 SSD1306。

输出：
    Core/Inc/wings_bitmap.h
    Core/Src/wings_bitmap.c
    docs/wings_frames.png
"""

from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
W, H = 96, 48
S = 8
FRAMES = 4
FRAME_BYTES = W * H // 8


def draw_frame(lift: int) -> Image.Image:
    img = Image.new("L", (W * S, H * S), 0)
    d = ImageDraw.Draw(img)

    def poly(points, fill=255):
        d.polygon([(x * S, y * S) for x, y in points], fill=fill)

    # 五根羽毛，左右镜像
    feathers = [
        [(46, 14), (5, 3 + lift), (9, 8 + lift), (23, 14), (38, 17)],
        [(46, 19), (2, 12 + lift), (7, 17 + lift), (21, 21), (38, 23)],
        [(46, 24), (3, 23 + lift), (8, 27 + lift), (22, 28), (38, 28)],
        [(46, 29), (6, 33 + lift), (11, 35 + lift), (24, 33), (38, 32)],
        [(46, 34), (13, 40 + lift), (18, 41 + lift), (29, 37), (40, 35)],
    ]
    for pts in feathers:
        poly(pts)
        poly([(W - x, y) for x, y in pts])

    # 中央盾/剑
    poly([(48, 3), (55, 12), (54, 33), (48, 45), (42, 33), (41, 12)])
    poly([(48, 8), (52, 14), (51, 31), (48, 39), (45, 31), (44, 14)], fill=0)
    poly([(48, 12), (49, 16), (49, 35), (48, 39), (47, 35), (47, 16)])

    # 羽毛之间的黑色分隔
    for y0, y1 in [(16, 6), (21, 13), (26, 24), (31, 33)]:
        d.line([(42 * S, y0 * S), (8 * S, y1 * S)], fill=0, width=1 * S)
        d.line([((W - 42) * S, y0 * S), ((W - 8) * S, y1 * S)], fill=0, width=1 * S)

    return img.resize((W, H), Image.LANCZOS).point(lambda p: 255 if p >= 110 else 0)


def to_xbm(img: Image.Image) -> list[int]:
    """U8g2 DrawXBMP: 行优先，每字节 8 个横向像素，bit0 在最左边。"""
    data = []
    for y in range(H):
        for bx in range((W + 7) // 8):
            value = 0
            for bit in range(8):
                x = bx * 8 + bit
                if x < W and img.getpixel((x, y)) > 0:
                    value |= 1 << bit
            data.append(value)
    return data


def c_array(data: list[int], indent: str = "    ") -> str:
    lines = []
    for i in range(0, len(data), 16):
        lines.append(indent + ", ".join(f"0x{v:02X}" for v in data[i:i + 16]) + ",")
    return "\n".join(lines)


def main():
    frames = [draw_frame(lift) for lift in (0, 4, 8, 4)]

    header = """/**
  ******************************************************************************
  * @file    wings_bitmap.h
  * @brief   自由之翼风格 96x48 动画帧（XBM，4 帧）。
  *          由 tools/make_wings.py 自动生成。
  ******************************************************************************
  */
#ifndef WINGS_BITMAP_H
#define WINGS_BITMAP_H

#include <stdint.h>

#define WINGS_WIDTH   96U
#define WINGS_HEIGHT  48U
#define WINGS_FRAMES  4U

extern const uint8_t wings_frames[WINGS_FRAMES][WINGS_WIDTH * WINGS_HEIGHT / 8U];

#endif /* WINGS_BITMAP_H */
"""
    (ROOT / "Core" / "Inc" / "wings_bitmap.h").write_text(header, encoding="utf-8", newline="\n")

    out = []
    out.append("/**")
    out.append("  ******************************************************************************")
    out.append("  * @file    wings_bitmap.c")
    out.append("  * @brief   自由之翼风格 96x48 动画帧，自动生成，请勿手改。")
    out.append("  ******************************************************************************")
    out.append("  */")
    out.append('#include "wings_bitmap.h"')
    out.append("")
    out.append("const uint8_t wings_frames[WINGS_FRAMES][WINGS_WIDTH * WINGS_HEIGHT / 8U] = {")
    for idx, frame in enumerate(frames):
        data = to_xbm(frame)
        if len(data) != FRAME_BYTES:
            raise RuntimeError(f"frame {idx} size {len(data)}")
        out.append(f"    /* frame {idx} */")
        out.append("    {")
        out.append(c_array(data, "        "))
        out.append("    },")
    out.append("};")
    out.append("")
    (ROOT / "Core" / "Src" / "wings_bitmap.c").write_text("\n".join(out),
                                                          encoding="utf-8", newline="\n")

    # 预览：四帧横排，放大 4 倍
    sheet = Image.new("L", (W * FRAMES, H), 0)
    for i, frame in enumerate(frames):
        sheet.paste(frame, (i * W, 0))
    sheet.resize((sheet.width * 4, sheet.height * 4), Image.NEAREST).save(
        ROOT / "docs" / "wings_frames.png")
    print("generated wings_bitmap.c/h and docs/wings_frames.png")


if __name__ == "__main__":
    main()
