# Build Task3_U8G2 with GNU Arm Embedded Toolchain.
# Usage:
#   powershell -ExecutionPolicy Bypass -File tools\build.ps1
#   powershell -ExecutionPolicy Bypass -File tools\build.ps1 -Toolchain "D:\gcc-arm\bin"

param(
    [string]$Toolchain = "C:\Program Files (x86)\Arm GNU Toolchain arm-none-eabi\14.2 rel1\bin"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$gcc = Join-Path $Toolchain "arm-none-eabi-gcc.exe"
if (-not (Test-Path $gcc)) {
    $cmd = Get-Command arm-none-eabi-gcc.exe -ErrorAction SilentlyContinue
    if ($cmd) {
        $Toolchain = Split-Path -Parent $cmd.Source
        $gcc = $cmd.Source
    } else {
        throw "arm-none-eabi-gcc.exe not found. Install GNU Arm Embedded Toolchain or pass -Toolchain <bin dir>."
    }
}

$objcopy = Join-Path $Toolchain "arm-none-eabi-objcopy.exe"
$size = Join-Path $Toolchain "arm-none-eabi-size.exe"

New-Item -ItemType Directory -Force -Path build, flash | Out-Null

$sources = @(
    "Startup\startup_stm32f103xb.s",
    "Core\Src\main.c",
    "Core\Src\app.c",
    "Core\Src\u8g2_port.c",
    "Core\Src\wings_bitmap.c",
    "Core\Src\bsp_i2c.c",
    "Core\Src\bsp_uart.c",
    "Core\Src\syscalls.c",
    "Core\Src\stm32f1xx_it.c",
    "Core\Src\stm32f1xx_hal_msp.c",
    "Core\Src\system_stm32f1xx.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_cortex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_dma.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_flash.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_flash_ex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_gpio.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_i2c.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_pwr.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_rcc.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_rcc_ex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_uart.c"
)

# Trimmed U8g2 core + 4 fonts (explicit list for stable parsing)
$u8g2_sources = @(
    "U8g2\csrc\u8g2_arc.c",
    "U8g2\csrc\u8g2_bitmap.c",
    "U8g2\csrc\u8g2_box.c",
    "U8g2\csrc\u8g2_buffer.c",
    "U8g2\csrc\u8g2_circle.c",
    "U8g2\csrc\u8g2_cleardisplay.c",
    "U8g2\csrc\u8g2_font.c",
    "U8g2\csrc\u8g2_hvline.c",
    "U8g2\csrc\u8g2_intersection.c",
    "U8g2\csrc\u8g2_kerning.c",
    "U8g2\csrc\u8g2_line.c",
    "U8g2\csrc\u8g2_ll_hvline.c",
    "U8g2\csrc\u8g2_polygon.c",
    "U8g2\csrc\u8g2_setup.c",
    "U8g2\csrc\u8x8_8x8.c",
    "U8g2\csrc\u8x8_byte.c",
    "U8g2\csrc\u8x8_capture.c",
    "U8g2\csrc\u8x8_cad.c",
    "U8g2\csrc\u8x8_display.c",
    "U8g2\csrc\u8x8_d_ssd1306_128x64_noname.c",
    "U8g2\csrc\u8x8_gpio.c",
    "U8g2\csrc\u8x8_setup.c",
    "U8g2\csrc\u8x8_string.c",
    "U8g2\csrc\u8x8_u16toa.c",
    "U8g2\csrc\u8x8_u8toa.c"
)

$font_sources = @(
    "U8g2\fonts\u8g2_font_10x20_tf.c",
    "U8g2\fonts\u8g2_font_5x8_tf.c",
    "U8g2\fonts\u8g2_font_6x10_tf.c",
    "U8g2\fonts\u8g2_font_7x14B_tf.c"
)

Write-Host "U8g2 sources: $($u8g2_sources.Count), fonts: $($font_sources.Count)"

$cflags = @(
    "-mcpu=cortex-m3",
    "-mthumb",
    "-mfloat-abi=soft",
    "-std=gnu11",
    "-Os",
    "-g3",
    "-Wall",
    "-Wextra",
    "-Wno-unused-parameter",
    "-ffunction-sections",
    "-fdata-sections",
    "-DUSE_HAL_DRIVER",
    "-DSTM32F103xB",
    "-ICore\Inc",
    "-IDrivers\STM32F1xx_HAL_Driver\Inc",
    "-IDrivers\STM32F1xx_HAL_Driver\Inc\Legacy",
    "-IDrivers\CMSIS\Device\ST\STM32F1xx\Include",
    "-IDrivers\CMSIS\Include",
    "-IU8g2\csrc"
)

$ldflags = @(
    "-mcpu=cortex-m3",
    "-mthumb",
    "-mfloat-abi=soft",
    "-T", "LD\STM32F103C8Tx_FLASH.ld",
    "-Wl,--gc-sections",
    "-Wl,--print-memory-usage",
    "-Wl,-Map=build\Task3_U8G2.map",
    "--specs=nano.specs",
    "-Wl,--no-warn-rwx-segments",
    "-lm"
)

Write-Host "==> Compiling and linking..."
& $gcc @cflags @sources @u8g2_sources @font_sources @ldflags -o "build\Task3_U8G2.elf"
if ($LASTEXITCODE -ne 0) { throw "gcc failed with exit code $LASTEXITCODE" }

Write-Host "==> Generating HEX/BIN..."
& $objcopy -O ihex "build\Task3_U8G2.elf" "flash\Task3_U8G2_gcc.hex"
if ($LASTEXITCODE -ne 0) { throw "objcopy hex failed" }
& $objcopy -O binary "build\Task3_U8G2.elf" "flash\Task3_U8G2_gcc.bin"
if ($LASTEXITCODE -ne 0) { throw "objcopy bin failed" }

Write-Host "==> Size:"
& $size "build\Task3_U8G2.elf"

Write-Host ""
Write-Host "Done:"
Write-Host "  build\Task3_U8G2.elf"
Write-Host "  build\Task3_U8G2.map"
Write-Host "  flash\Task3_U8G2_gcc.hex"
Write-Host "  flash\Task3_U8G2_gcc.bin"
