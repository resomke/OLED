/**
  ******************************************************************************
  * @file    app.c
  * @brief   任务三：U8g2 在 STM32F103C8T6 + SSD1306 上的综合显示。
  *
  * 页面：
  *   1/5  U8g2 demo：字体、矩形、圆、三角形、动态小球
  *   2/5  ReSm0ke + 学号
  *   3/5  上下滚动（纵向字幕）
  *   4/5  左右滚动（横向跑马灯）
  *   5/5  自由之翼动态图案（4 帧 + 扫描线 + 闪烁星点）
  ******************************************************************************
  */
#include "app.h"
#include "app_config.h"
#include "board.h"
#include "bsp_uart.h"
#include "main.h"
#include "u8g2_port.h"
#include "wings_bitmap.h"
#include <string.h>

typedef enum
{
    PAGE_DEMO = 0,
    PAGE_PROFILE,
    PAGE_VSCROLL,
    PAGE_HSCROLL,
    PAGE_WINGS,
    PAGE_COUNT
} app_page_t;

static app_page_t s_page = PAGE_DEMO;
static uint32_t s_page_tick;
static uint32_t s_frame_tick;
static uint32_t s_led_tick;
static uint32_t s_retry_tick;
static bool s_oled_ok;

static const char *const s_vlines[] =
{
    "ReSm0ke",
    "632407030413",
    "CQJTU IOT205",
    "Wings of Freedom",
    "U8g2 on STM32F103",
    "SSD1306 128x64",
    "Hello, world!",
    "Never stop flying."
};

#define VLINE_COUNT (sizeof(s_vlines) / sizeof(s_vlines[0]))

static const char *page_name(app_page_t page)
{
    switch (page)
    {
        case PAGE_DEMO:    return "U8g2 demo";
        case PAGE_PROFILE: return "profile";
        case PAGE_VSCROLL: return "vertical scroll";
        case PAGE_HSCROLL: return "horizontal scroll";
        case PAGE_WINGS:   return "wings";
        default:           return "?";
    }
}

static void draw_header(app_page_t page)
{
    char label[4];

    label[0] = (char)('1' + (char)page);
    label[1] = '/';
    label[2] = (char)('0' + (char)PAGE_COUNT);
    label[3] = '\0';

    u8g2_SetFont(&u8g2, u8g2_font_5x8_tf);
    u8g2_DrawStr(&u8g2, 0, 8, "U8G2 / STM32F103");
    u8g2_DrawStr(&u8g2, 110, 8, label);
    u8g2_DrawHLine(&u8g2, 0, 10, 128);
}

static void draw_cross(uint8_t x, uint8_t y)
{
    u8g2_DrawPixel(&u8g2, x, y);
    u8g2_DrawPixel(&u8g2, (uint8_t)(x - 1), y);
    u8g2_DrawPixel(&u8g2, (uint8_t)(x + 1), y);
    u8g2_DrawPixel(&u8g2, x, (uint8_t)(y - 1));
    u8g2_DrawPixel(&u8g2, x, (uint8_t)(y + 1));
}

static void draw_demo(uint32_t anim)
{
    int16_t ball_x;

    u8g2_ClearBuffer(&u8g2);
    draw_header(PAGE_DEMO);
    u8g2_DrawFrame(&u8g2, 0, 12, 128, 51);

    u8g2_SetFont(&u8g2, u8g2_font_10x20_tf);
    u8g2_DrawStr(&u8g2, 4, 32, "U8g2");

    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
    u8g2_DrawStr(&u8g2, 4, 43, "STM32F103");
    u8g2_DrawStr(&u8g2, 4, 54, "SSD1306 I2C");

    u8g2_DrawCircle(&u8g2, 100, 22, 8, U8G2_DRAW_ALL);
    u8g2_DrawDisc(&u8g2, 100, 22, 3, U8G2_DRAW_ALL);
    u8g2_DrawBox(&u8g2, 112, 14, 8, 8);
    u8g2_DrawTriangle(&u8g2, 108, 48, 122, 48, 115, 38);
    u8g2_DrawLine(&u8g2, 88, 56, 124, 56);

    ball_x = (int16_t)(4 + (anim / 18U) % 120U);
    u8g2_DrawDisc(&u8g2, (u8g2_uint_t)ball_x, 59, 2, U8G2_DRAW_ALL);
}

static void draw_profile(uint32_t anim)
{
    u8g2_uint_t name_w;
    u8g2_uint_t id_w;
    u8g2_uint_t school_w;
    int16_t name_x;
    int16_t id_x;
    int16_t school_x;
    uint8_t fill;

    u8g2_ClearBuffer(&u8g2);
    draw_header(PAGE_PROFILE);

    u8g2_SetFont(&u8g2, u8g2_font_10x20_tf);
    name_w = u8g2_GetStrWidth(&u8g2, NICKNAME);
    name_x = (int16_t)(((int16_t)128 - (int16_t)name_w) / 2);
    u8g2_DrawStr(&u8g2, (u8g2_uint_t)name_x, 33, NICKNAME);

    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
    id_w = u8g2_GetStrWidth(&u8g2, STUDENT_ID);
    id_x = (int16_t)(((int16_t)128 - (int16_t)id_w) / 2);
    u8g2_DrawStr(&u8g2, (u8g2_uint_t)id_x, 45, STUDENT_ID);

    u8g2_SetFont(&u8g2, u8g2_font_5x8_tf);
    school_w = u8g2_GetStrWidth(&u8g2, SCHOOL_LINE);
    school_x = (int16_t)(((int16_t)128 - (int16_t)school_w) / 2);
    u8g2_DrawStr(&u8g2, (u8g2_uint_t)school_x, 57, SCHOOL_LINE);

    /* 名字下方动态填充的横线 */
    fill = (uint8_t)((anim / 6U) % (name_w + 1U));
    u8g2_DrawBox(&u8g2, (u8g2_uint_t)name_x, 34, fill, 1);

    /* 闪烁光标 */
    if (((anim / 250U) & 1U) != 0U)
    {
        u8g2_DrawBox(&u8g2, (u8g2_uint_t)(name_x + name_w + 2), 30, 2, 3);
    }

    draw_cross(8, 20);
    draw_cross(120, 20);
}

static void draw_vscroll(uint32_t anim)
{
    uint16_t total = (uint16_t)(VLINE_COUNT * 12U);
    uint16_t off = (uint16_t)((anim / 35U) % (total + 40U));
    uint8_t thumb;

    u8g2_ClearBuffer(&u8g2);
    draw_header(PAGE_VSCROLL);
    u8g2_DrawFrame(&u8g2, 0, 12, 128, 51);

    u8g2_SetClipWindow(&u8g2, 1, 14, 127, 62);
    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);

    for (uint8_t i = 0; i < VLINE_COUNT; ++i)
    {
        int16_t y = (int16_t)(26 + i * 12 - off);
        if ((y >= 14) && (y <= 64))
        {
            u8g2_DrawStr(&u8g2, 4, (u8g2_uint_t)y, s_vlines[i]);
        }
    }

    u8g2_SetMaxClipWindow(&u8g2);

    /* 右侧滚动条 */
    u8g2_DrawVLine(&u8g2, 124, 14, 48);
    thumb = (uint8_t)(14U + (off * 44U) / (total + 40U));
    u8g2_DrawBox(&u8g2, 123, thumb, 3, 4);
}

static void append_limited(char *dst, size_t dst_size,
                           const char *src, size_t len)
{
    size_t used = strlen(dst);
    size_t room;

    if (used >= (dst_size - 1U))
    {
        return;
    }

    room = dst_size - 1U - used;
    if (len > room)
    {
        len = room;
    }

    memcpy(&dst[used], src, len);
    dst[used + len] = '\0';
}

static void draw_hscroll(uint32_t anim)
{
    static char marquee[300];
    size_t n = strlen(HORIZONTAL_TEXT);
    size_t start;
    u8g2_uint_t w;

    if (n == 0U)
    {
        return;
    }

    u8g2_ClearBuffer(&u8g2);
    draw_header(PAGE_HSCROLL);
    u8g2_DrawHLine(&u8g2, 0, 12, 128);

    /* 按字符循环拼接，保证从 0 开始绘制，不依赖负坐标 */
    start = (size_t)((anim / 60U) % n);
    marquee[0] = '\0';
    append_limited(marquee, sizeof(marquee), HORIZONTAL_TEXT + start, n - start);
    append_limited(marquee, sizeof(marquee), HORIZONTAL_TEXT, start);
    append_limited(marquee, sizeof(marquee), HORIZONTAL_TEXT, n);

    u8g2_SetClipWindow(&u8g2, 0, 15, 128, 47);
    u8g2_SetFont(&u8g2, u8g2_font_7x14B_tf);
    u8g2_DrawStr(&u8g2, 0, 38, marquee);
    u8g2_SetMaxClipWindow(&u8g2);

    u8g2_DrawHLine(&u8g2, 0, 48, 128);
    u8g2_SetFont(&u8g2, u8g2_font_5x8_tf);
    u8g2_DrawStr(&u8g2, 0, 60, "left marquee  I2C 400kHz");

    w = u8g2_GetStrWidth(&u8g2, HORIZONTAL_TEXT);
    (void)w;
}

static void draw_wings(uint32_t anim)
{
    static const uint8_t spark_x[6] = {4, 120, 6, 118, 10, 114};
    static const uint8_t spark_y[6] = {10, 12, 36, 34, 2, 2};
    uint8_t frame = (uint8_t)((anim / 120U) % WINGS_FRAMES);
    uint8_t scan = (uint8_t)((anim / 80U) % WINGS_HEIGHT);
    u8g2_uint_t w;

    u8g2_ClearBuffer(&u8g2);
    u8g2_DrawXBMP(&u8g2, 16, 0, WINGS_WIDTH, WINGS_HEIGHT,
                  wings_frames[frame]);

    /* 黑色扫描线扫过翅膀，形成“呼吸/扫描”效果 */
    u8g2_SetDrawColor(&u8g2, 0);
    u8g2_DrawHLine(&u8g2, 16, scan, WINGS_WIDTH);
    u8g2_SetDrawColor(&u8g2, 1);

    for (uint8_t i = 0; i < 6U; ++i)
    {
        if ((((anim / 100U) + i) % 3U) == 0U)
        {
            draw_cross(spark_x[i], spark_y[i]);
        }
    }

    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
    w = u8g2_GetStrWidth(&u8g2, NICKNAME);
    u8g2_DrawStr(&u8g2, (u8g2_uint_t)((128 - (int16_t)w) / 2),
                 62, NICKNAME);
}

static void app_render(uint32_t anim)
{
    switch (s_page)
    {
        case PAGE_DEMO:
            draw_demo(anim);
            break;
        case PAGE_PROFILE:
            draw_profile(anim);
            break;
        case PAGE_VSCROLL:
            draw_vscroll(anim);
            break;
        case PAGE_HSCROLL:
            draw_hscroll(anim);
            break;
        case PAGE_WINGS:
            draw_wings(anim);
            break;
        default:
            break;
    }

    u8g2_port_send();
}

static uint32_t page_duration(app_page_t page)
{
    switch (page)
    {
        case PAGE_DEMO:    return PAGE_DEMO_MS;
        case PAGE_PROFILE: return PAGE_PROFILE_MS;
        case PAGE_VSCROLL: return PAGE_VSCROLL_MS;
        case PAGE_HSCROLL: return PAGE_HSCROLL_MS;
        case PAGE_WINGS:   return PAGE_WINGS_MS;
        default:           return 5000U;
    }
}

static void app_enter_page(app_page_t page)
{
    s_page = page;
    s_page_tick = HAL_GetTick();
    s_frame_tick = s_page_tick - APP_FRAME_MS;

#if APP_USE_UART_LOG
    bsp_uart_puts("page: ");
    bsp_uart_puts(page_name(page));
    bsp_uart_newline();
#endif
}

static void app_next_page(void)
{
    app_enter_page((app_page_t)(((uint8_t)s_page + 1U) %
                                (uint8_t)PAGE_COUNT));
}

#if APP_USE_KEY_PA0
static bool key_take_press(void)
{
    static uint8_t stable = 1U;
    static uint8_t last = 1U;
    static uint32_t change_tick;

    uint8_t raw = (HAL_GPIO_ReadPin(KEY_PORT, KEY_PIN) == GPIO_PIN_RESET)
                      ? 0U : 1U;
    uint32_t now = HAL_GetTick();

    if (raw != last)
    {
        last = raw;
        change_tick = now;
    }

    if (((now - change_tick) > 20U) && (raw != stable))
    {
        stable = raw;
        if (stable == 0U)
        {
            return true;
        }
    }

    return false;
}
#endif

void app_init(void)
{
    s_oled_ok = u8g2_port_init();

#if APP_USE_UART_LOG
    bsp_uart_puts("U8g2 / SSD1306: ");
    if (s_oled_ok)
    {
        bsp_uart_puts("found at ");
        bsp_uart_put_hex8(u8g2_port_addr7());
        bsp_uart_newline();
    }
    else
    {
        bsp_uart_puts("NOT FOUND (PB6/PB7, 0x3C/0x3D)\r\n");
    }
#endif

    app_enter_page(PAGE_DEMO);

    if (!s_oled_ok)
    {
        s_retry_tick = HAL_GetTick();
    }
}

void app_run(void)
{
    for (;;)
    {
        uint32_t now = HAL_GetTick();

        if (!s_oled_ok)
        {
            if ((now - s_retry_tick) >= 2000U)
            {
                s_retry_tick = now;
                s_oled_ok = u8g2_port_init();
                if (s_oled_ok)
                {
                    app_enter_page(PAGE_DEMO);
                }
            }

            if ((now - s_led_tick) >= 250U)
            {
                s_led_tick = now;
                LED_TOGGLE();
            }

            HAL_Delay(10);
            continue;
        }

#if APP_USE_KEY_PA0
        if (key_take_press())
        {
            app_next_page();
            now = HAL_GetTick();
        }
#endif

        if ((now - s_page_tick) >= page_duration(s_page))
        {
            app_next_page();
            now = HAL_GetTick();
        }

        if ((now - s_frame_tick) >= APP_FRAME_MS)
        {
            s_frame_tick = now;
            app_render(now - s_page_tick);
        }

        if ((now - s_led_tick) >= 500U)
        {
            s_led_tick = now;
            LED_TOGGLE();
        }

        HAL_Delay(2);
    }
}
