#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
任务三页面布局示意图（不是实物拍照）。

用 Consolas 近似 U8g2 的 5x8 / 6x10 / 7x14B / 10x20 字体，
自由之翼使用 make_wings.py 生成的真实点阵帧。
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
W, H = 128, 64
FONT = r"C:\Windows\Fonts\consola.ttf"
FONTB = r"C:\Windows\Fonts\consolab.ttf"

f5 = ImageFont.truetype(FONT, 8)
f6 = ImageFont.truetype(FONT, 10)
f7 = ImageFont.truetype(FONTB, 14)
f10 = ImageFont.truetype(FONTB, 20)


def new_page():
    img = Image.new("L", (W, H), 0)
    return img, ImageDraw.Draw(img)


def text(d, xy, s, font, fill=255):
    d.text(xy, s, font=font, fill=fill, anchor="ls")


def header(d, page):
    text(d, (0, 8), "U8G2 / STM32F103", f5)
    text(d, (110, 8), f"{page}/5", f5)
    d.line((0, 10, 127, 10), fill=255)


def frame(d, x, y, w, h):
    d.rectangle((x, y, x + w - 1, y + h - 1), outline=255)


def center_x(s, font):
    return (W - int(font.getlength(s))) // 2


def page_demo():
    img, d = new_page()
    header(d, 1)
    frame(d, 0, 12, 128, 51)
    text(d, (4, 32), "U8g2", f10)
    text(d, (4, 43), "STM32F103", f6)
    text(d, (4, 54), "SSD1306 I2C", f6)
    d.ellipse((92, 14, 108, 30), outline=255)
    d.ellipse((97, 19, 103, 25), fill=255)
    d.rectangle((112, 14, 120, 22), fill=255)
    d.polygon([(108, 48), (122, 48), (115, 38)], outline=255)
    d.line((88, 56, 124, 56), fill=255)
    d.ellipse((58, 57, 62, 61), fill=255)
    return img


def page_profile():
    img, d = new_page()
    header(d, 2)
    name = "ReSm0ke"
    text(d, (center_x(name, f10), 33), name, f10)
    sid = "632407030413"
    text(d, (center_x(sid, f6), 45), sid, f6)
    school = "CQJTU IOT205"
    text(d, (center_x(school, f5), 57), school, f5)
    x = center_x(name, f10)
    d.line((x, 34, x + 50, 34), fill=255)
    d.rectangle((x + 52, 30, x + 53, 32), fill=255)
    for cx, cy in [(8, 20), (120, 20)]:
        d.line((cx - 2, cy, cx + 2, cy), fill=255)
        d.line((cx, cy - 2, cx, cy + 2), fill=255)
    return img


def page_vertical():
    img, d = new_page()
    header(d, 3)
    frame(d, 0, 12, 128, 51)
    lines = [
        "ReSm0ke", "632407030413", "CQJTU IOT205",
        "Wings of Freedom", "U8g2 on STM32F103",
        "SSD1306 128x64", "Hello, world!", "Never stop flying."
    ]
    off = 22
    for i, s in enumerate(lines):
        y = 26 + i * 12 - off
        if 14 <= y <= 62:
            text(d, (4, y), s, f6)
    d.line((124, 14, 124, 62), fill=255)
    d.rectangle((123, 22, 125, 27), fill=255)
    return img


def page_horizontal():
    img, d = new_page()
    header(d, 4)
    d.line((0, 12, 127, 12), fill=255)
    s = "ReSm0ke  *  632407030413  *  CQJTU IOT205  *"
    text(d, (0, 38), s, f7)
    d.line((0, 48, 127, 48), fill=255)
    text(d, (0, 60), "left marquee  I2C 400kHz", f5)
    return img


def page_wings():
    img, d = new_page()
    sheet = Image.open(ROOT / "docs" / "wings_frames.png").convert("L")
    # 4 frames horizontally, each 96x48 at 4x
    frame0 = sheet.crop((0, 0, 96 * 4, 48 * 4)).resize((96, 48), Image.LANCZOS)
    frame0 = frame0.point(lambda p: 255 if p > 100 else 0)
    img.paste(frame0, (16, 0))
    # black scan line (erases a stripe across the wings)
    d.line((16, 28, 112, 28), fill=0)
    for x, y in [(4, 10), (120, 12), (6, 36), (118, 34)]:
        d.line((x - 1, y, x + 1, y), fill=255)
        d.line((x, y - 1, x, y + 1), fill=255)
    name = "ReSm0ke"
    text(d, (center_x(name, f6), 62), name, f6)
    return img


def main():
    pages = [page_demo(), page_profile(), page_vertical(), page_horizontal(), page_wings()]
    labels = ["1/5  U8g2 demo", "2/5  ReSm0ke + 学号",
              "3/5  上下滚动", "4/5  左右滚动", "5/5  自由之翼动画"]
    scale = 4
    margin, gap, label_h = 22, 18, 26
    sw = margin * 2 + len(pages) * W * scale + (len(pages) - 1) * gap
    sh = margin * 2 + H * scale + label_h
    out = Image.new("RGB", (sw, sh), (18, 20, 26))
    od = ImageDraw.Draw(out)
    lf = ImageFont.truetype(r"C:\Windows\Fonts\simhei.ttf", 14)

    for i, (page, label) in enumerate(zip(pages, labels)):
        x = margin + i * (W * scale + gap)
        y = margin
        od.rounded_rectangle((x - 5, y - 5, x + W * scale + 5, y + H * scale + 5),
                             radius=7, fill=(8, 9, 12), outline=(68, 72, 84), width=2)
        big = page.convert("RGB").resize((W * scale, H * scale), Image.NEAREST)
        out.paste(big, (x, y))
        od.text((x, y + H * scale + 6), label, font=lf, fill=(210, 214, 224))

    out.save(ROOT / "docs" / "ui_preview.png")
    print("written docs/ui_preview.png")


if __name__ == "__main__":
    main()
