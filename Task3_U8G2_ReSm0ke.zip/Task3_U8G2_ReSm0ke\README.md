# 任务三：U8g2 移植到 STM32F103C8T6 + SSD1306

> 昵称：**ReSm0ke**  
> 学号：**632407030413**  
> 芯片：STM32F103C8T6（64 KB Flash / 20 KB RAM）  
> 屏幕：0.96 寸 128×64 I2C OLED（SSD1306）  
> 图形库：U8g2（裁剪后移植到 STM32 HAL）  
> 主固件：`flash/Task3_U8G2.hex`，可直接烧录

![五个页面布局示意](docs/ui_preview.png)

> 上图是布局示意图，不是实物拍照；实物为黑底白字。

---

## 1. 对应任务三的四项要求

| 要求 | 本工程实现 | 页面 |
|---|---|---|
| U8g2 demo 例程 | 字体、矩形、圆、三角形、动态小球 | 1/5 |
| 显示自己的学号/昵称 | `ReSm0ke` + `632407030413` | 2/5 |
| 上下、左右滑动 | 纵向字幕 + 横向跑马灯 | 3/5、4/5 |
| 显示图案，最好动态 | 自由之翼 4 帧动画 + 扫描线 + 星点 | 5/5 |

上电自动轮播，PA0 按键（接 GND）可手动切页；PC13 LED 心跳。

---

## 2. 接线

与任务一相同：

| STM32F103C8T6 | OLED | 说明 |
|---|---|---|
| 3.3V | VCC | 必须 3.3 V |
| GND | GND | 共地 |
| PB6 | SCL | I2C1 SCL，400 kHz |
| PB7 | SDA | I2C1 SDA，400 kHz |
| PA0 | — | 可选按键到 GND，手动切页 |
| PC13 | — | 板载 LED |

![接线图](docs/wiring.png)

OLED 模块一般自带上拉；如果没有，SCL/SDA 各接 4.7 kΩ 到 3.3 V。  
I2C 地址一般是 `0x3C`，少数模块 `0x3D`，代码会自动探测。

---

## 3. 直接烧录

### 方式 A：STM32CubeProgrammer + ST-Link

1. ST-Link：`SWDIO → PA13`、`SWCLK → PA14`、`GND → GND`、`3.3V → 3.3V`。
2. BOOT0 = 0，复位。
3. 打开 [flash/Task3_U8G2.hex](flash/Task3_U8G2.hex)，Download，复位运行。

命令行：

```powershell
STM32_Programmer_CLI.exe -c port=SWD -w flash\Task3_U8G2.hex -v -rst
```

### 方式 B：Keil

打开 [MDK-ARM/Task3_U8G2.uvprojx](MDK-ARM/Task3_U8G2.uvprojx)：

- Device：`STM32F103C8`
- Compiler：ARM Compiler 6（本机实测 V6.7）
- Debug：ST-Link Debugger，Port `SW`
- Flash Download：`STM32F10x_128`，起始 `0x08000000`
- 按 **F7** 编译，**F8** 下载

> 工程已经去掉 RTE 组件，不需要安装 CMSIS/GUI/MDK-Middleware。  
> 如果 Keil 弹出组件安装提示，直接 Cancel 不装也能编译。

### 方式 C：GCC 编译

```powershell
powershell -ExecutionPolicy Bypass -File tools\build.ps1
```

输出：

```text
flash/Task3_U8G2_gcc.hex
flash/Task3_U8G2_gcc.bin
```

---

## 4. 五个页面

### 1/5  U8g2 demo

- 10×20 字体显示 `U8g2`
- 6×10 字体显示 `STM32F103`、`SSD1306 I2C`
- 画圆、实心圆、矩形、三角形、直线
- 底部一个小球来回运动

对应 U8g2 的 `DrawStr`、`DrawCircle`、`DrawDisc`、`DrawBox`、`DrawTriangle`、`DrawLine`。

### 2/5  ReSm0ke

- 10×20 字体显示昵称 `ReSm0ke`
- 6×10 字体显示学号 `632407030413`
- 5×8 字体显示 `CQJTU IOT205`
- 名字下方有动态填充横线和闪烁光标

### 3/5  上下滚动

- 固定页眉和边框
- 8 行字幕在 viewport 内向上平滑滚动
- 右侧有滚动条
- 用 `u8g2_SetClipWindow()` 限制绘制区域，防止字幕画出边框

### 4/5  左右滚动

- `ReSm0ke * 632407030413 * CQJTU IOT205 * Wings of Freedom`
- 使用 7×14B 字体，在 128 像素窗口内循环横向移动
- 因为 U8g2 的坐标是 `u8g2_uint_t`，这里采用**按字符循环拼接**的方式，避免负坐标不被绘制的问题；每步 7 像素

### 5/5  自由之翼

- 96×48 点阵，4 帧翅膀扇动
- 每 120 ms 切一帧
- 一条黑色扫描线从上到下扫过
- 周围星点闪烁
- 底部显示 `ReSm0ke`

![自由之翼四帧](docs/wings_frames.png)

![自由之翼动画示意](docs/wings_animation.gif)

> 图案是受《进击的巨人》自由之翼启发的**简化 fan-art 点阵**，不是官方素材；用 1-bit 重新绘制，适合 SSD1306。

---

## 5. U8g2 移植与裁剪

### 5.1 保留的文件

`U8g2/csrc` 只保留了 25 个核心文件：

```text
u8g2_arc.c / bitmap.c / box.c / buffer.c / circle.c
u8g2_cleardisplay.c / font.c / hvline.c / intersection.c
u8g2_kerning.c / line.c / ll_hvline.c / polygon.c / setup.c
u8x8_8x8.c / byte.c / cad.c / capture.c / display.c
u8x8_d_ssd1306_128x64_noname.c / gpio.c / setup.c
u8x8_string.c / u16toa.c / u8toa.c
```

没有把 39 MB 的 `u8g2_fonts.c` 和几百 KB 的 `u8g2_d_setup.c` 全部加进来，而是：

1. 只保留 4 个字体：
   - `u8g2_font_5x8_tf`
   - `u8g2_font_6x10_tf`
   - `u8g2_font_7x14B_tf`
   - `u8g2_font_10x20_tf`
2. 不调用 `u8g2_Setup_ssd1306_i2c_128x64_noname_f()`，而是手动调用：

```c
u8g2_SetupDisplay(&u8g2,
                  u8x8_d_ssd1306_128x64_noname,
                  u8x8_cad_ssd13xx_fast_i2c,
                  u8x8_byte_stm32_hw_i2c,
                  u8x8_gpio_and_delay_stm32);

u8g2_SetupBuffer(&u8g2, s_u8g2_buffer, 8,
                 u8g2_ll_hvline_vertical_top_lsb,
                 U8G2_R0);
```

这样只把 SSD1306 128×64 的驱动和 1 KB 全屏缓冲链进来，Flash 占用约 30.3 KB（Keil AC6）。

### 5.2 I2C 回调的关键点

U8g2 会把控制字节 `0x00`（命令）或 `0x40`（数据）和数据分两次 `BYTE_SEND` 回调发来，但 SSD1306 要求它们在同一次 I2C 传输中。因此 `u8g2_port.c` 里做了缓存：

```c
START_TRANSFER -> 清空 buffer
BYTE_SEND      -> 追加到 buffer
END_TRANSFER   -> HAL_I2C_Master_Transmit(buffer 一次性发出)
```

如果直接在每次 `BYTE_SEND` 里发 I2C，数据会被 SSD1306 当成新的控制字节，屏幕不会正常显示。

### 5.3 字节/延时回调

- `U8X8_MSG_BYTE_SEND`：缓存
- `U8X8_MSG_DELAY_MILLI`：`HAL_Delay`
- `U8X8_MSG_DELAY_10MICRO`：短循环
- 其他 GPIO 消息：返回成功

---

## 6. 修改昵称/学号/滚动文字

打开 [Core/Inc/app_config.h](Core/Inc/app_config.h)：

```c
#define NICKNAME        "ReSm0ke"
#define STUDENT_ID      "632407030413"
#define SCHOOL_LINE     "CQJTU IOT205"
#define HORIZONTAL_TEXT "ReSm0ke  *  632407030413  *  CQJTU IOT205  *  Wings of Freedom  *  "
```

改完直接 Keil F7/F8，或者运行 GCC 脚本。

注意：

- 本工程的 U8g2 字体是 **ASCII 字体**，只支持英文、数字、常用符号；
- 如果要把昵称改成中文，需要额外加入 U8g2 中文点阵字体（体积较大，可能超过 Keil Lite 32 KB 限制），或者沿用任务一的自定义 16×16 汉字字库；
- `HORIZONTAL_TEXT` 可以加长，程序会循环拼接；
- 竖直滚动文字在 `Core/Src/app.c` 的 `s_vlines[]` 数组里修改。

---

## 7. 工程结构

```text
Task3_U8G2_ReSm0ke/
├─ Core/
│  ├─ Inc/
│  │  ├─ app_config.h        # 昵称、学号、横向跑马灯文字
│  │  ├─ u8g2_port.h
│  │  ├─ wings_bitmap.h      # 自由之翼点阵声明
│  │  └─ ...
│  └─ Src/
│     ├─ main.c              # HAL、72/64 MHz 时钟、GPIO
│     ├─ app.c               # 五个页面、动画、按键
│     ├─ u8g2_port.c         # U8g2 -> HAL I2C 移植层
│     ├─ wings_bitmap.c      # 4 帧 96x48 点阵
│     ├─ bsp_i2c.c           # I2C1 400 kHz + 总线恢复
│     ├─ bsp_uart.c          # 115200 日志
│     └─ ...
├─ U8g2/
│  ├─ csrc/                  # 裁剪后的 25 个 U8g2 源文件
│  ├─ fonts/                 # 4 个字体
│  └─ LICENSE
├─ Drivers/                  # CMSIS + STM32F1 HAL
├─ MDK-ARM/
│  └─ Task3_U8G2.uvprojx     # Keil 工程
├─ flash/
│  ├─ Task3_U8G2.hex         # Keil AC6 编译版（主烧录文件）
│  ├─ Task3_U8G2.bin
│  ├─ Task3_U8G2_gcc.hex
│  └─ Task3_U8G2_gcc.bin
├─ tools/
│  ├─ build.ps1              # GCC 编译
│  ├─ make_wings.py          # 生成自由之翼点阵
│  └─ preview_ui.py          # 生成页面示意图
└─ docs/
   ├─ wiring.png
   ├─ ui_preview.png
   ├─ wings_frames.png
   └─ wings_animation.gif
```

---

## 8. 编译结果

Keil AC6（本机 Keil 5.24a + AC6 6.7 + DFP 2.2.0）：

```text
Program Size: Code=18276  RO-data=11976  RW-data=16  ZI-data=4328
0 Error(s), 0 Warning(s)

FLASH 约 30272 B / 64 KB  (46.2%)
RAM   = 4344 B / 20 KB   (21.2%)
```

GCC 14.2：

```text
FLASH = 26432 B / 64 KB  (40.3%)
RAM   = 4864 B / 20 KB   (23.8%)
```

> Keil MDK-Lite 的 32 KB 限制：当前 Keil 版本约 30.3 KB，已经比较接近上限。  
> 如果后续再加中文字库或更多 U8g2 字体，建议用完整版 Keil 或 GCC 编译。

---

## 9. 常见问题

### 屏幕不亮

- 3.3 V、GND、PB6/SCL、PB7/SDA 是否接对；
- 用串口看启动日志：

  ```text
  U8g2 / SSD1306: found at 0x3C
  ```

- 如果 `NOT FOUND`，检查地址 0x3C/0x3D 和上拉电阻；
- 杜邦线太长时，先把 I2C 降到 100 kHz 测试。

### 屏幕有字但花屏/错位

- 检查 `u8g2_port.c` 的缓存回调是否被改动；
- 确认 `u8g2_SetupBuffer` 使用的是 `u8g2_ll_hvline_vertical_top_lsb` 和 `U8G2_R0`；
- 确认 OLED 是 SSD1306 128×64，不是 SH1106。

### 只显示一部分/滚动不正常

- 竖屏滚动靠 `u8g2_SetClipWindow`，检查 viewport 坐标；
- 横屏跑马灯是按字符拼接，文字太长时缓冲区 300 字节，正常英文短句足够；如果需要超长文本，把 `marquee[300]` 加大。

### Keil 提示安装 CMSIS/GUI

本工程不使用 RTE，CMSIS/HAL 都在 `Drivers/` 下，直接 Cancel 不安装即可。

---

## 10. CubeMX 配置（复现用）

本工程按 CubeMX 的 HAL 框架组织；如果要自己用 CubeMX 重新生成，按下面配置：

| 项目 | 设置 |
|---|---|
| MCU | STM32F103C8Tx |
| RCC | HSE：Crystal/Ceramic Resonator |
| Clock | HSE 8 MHz，PLL ×9，SYSCLK 72 MHz，APB1 /2，APB2 /1 |
| I2C1 | I2C，400 kHz，PB6=SCL，PB7=SDA |
| USART1 | Asynchronous，115200，8N1，PA9=TX，PA10=RX |
| GPIO | PC13 输出（LED），PA0 输入上拉（按键） |
| Project | MDK-ARM，ARM Compiler 6 |

生成后把 `Core/Src/app.c`、`u8g2_port.c`、`wings_bitmap.c` 和 `U8g2/` 加进工程，把 `main.c` 的 `while (1)` 换成 `app_run()` 即可。

---

## 11. Keil 虚拟逻辑分析仪与 SDA 波形

Keil 的 Logic Analyzer 通过 SWD/JTAG 读变量或外设寄存器，采样率通常只有毫秒级，**不能真实还原 400 kHz 的 I2C 引脚波形**。直接在 Logic Analyzer 里看 `GPIOB->IDR`，通常只会得到严重欠采样的稀疏跳变，不能解码 START/地址/ACK。

下面这张图是按本工程实际 I2C 时序重建的仿真波形：

- 400 kHz，SCL 周期 2.5 µs
- 写 OLED 地址 0x3C → 0x78
- 控制字节 0x00
- 命令 0xAF（display on）
- 包含 START、地址位、ACK、控制字节、数据、STOP

![I2C SDA/SCL 仿真波形](docs/i2c_sda_waveform.png)

> 这不是 Keil 的截图，而是按工程时序重建的仿真图，用于原理说明和报告配图。  
> 真实 I2C 波形请用 Saleae/PulseView 逻辑分析仪（采样率 ≥4 MHz，推荐 24 MHz）或双通道示波器测量。

---

## 12. 说明

- 任务三的 U8g2 源码来自 [olikraus/u8g2](https://github.com/olikraus/u8g2)，BSD 许可证，`U8g2/LICENSE` 已保留。
- 自由之翼为简化 fan-art 点阵，仅用于课程作业。
- 任务一（AHT20 + 自定义 OLED 驱动）工程仍然保留在 `STM32F103C8T6_Task1_OLED`，两个工程互相独立。
