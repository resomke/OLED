#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按 I2C 400 kHz 时序重建一张 SDA/SCL 仿真波形图。

事务：START + 0x78(写) + ACK + 0x00(控制字节) + ACK + 0xAF(display on) + ACK + STOP
OLED 地址 0x3C，写地址 0x78。

注意：这是按时序重建的仿真图，不是 Keil Logic Analyzer 的真实截图。
Keil 的虚拟逻辑分析仪通过 SWD 读变量/寄存器，采样率不足以还原 400 kHz
的真实 I2C 引脚波形。
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "docs" / "i2c_sda_waveform.png"

S = 2
W, H = 2000, 820
BG = (14, 17, 23)
PANEL = (23, 28, 37)
GRID = (44, 52, 66)
TEXT = (228, 233, 242)
MUTED = (156, 166, 184)
SCL_COLOR = (80, 200, 255)
SDA_COLOR = (255, 190, 70)
START_COLOR = (255, 110, 110)
ACK_COLOR = (120, 230, 160)
NOTE = (255, 210, 120)

FONT = r"C:\Windows\Fonts\consola.ttf"
FONTB = r"C:\Windows\Fonts\consolab.ttf"
FONT_CN = r"C:\Windows\Fonts\simhei.ttf"

f_title = ImageFont.truetype(FONT_CN, 34 * S)
f_sub = ImageFont.truetype(FONT_CN, 20 * S)
f_lab = ImageFont.truetype(FONTB, 24 * S)
f_small = ImageFont.truetype(FONT, 17 * S)
f_bit = ImageFont.truetype(FONTB, 18 * S)
f_cn = ImageFont.truetype(FONT_CN, 18 * S)
f_cn_small = ImageFont.truetype(FONT_CN, 16 * S)

LEFT = 170 * S
RIGHT = 70 * S
TOP = 150 * S
BOT = 610 * S
T_MAX = 80.0

SCL_HIGH, SCL_LOW = 250 * S, 330 * S
SDA_HIGH, SDA_LOW = 430 * S, 510 * S
X0 = LEFT
PLOT_W = W * S - LEFT - RIGHT


def tx(t):
    return int(round(X0 + (t / T_MAX) * PLOT_W))


def line(d, x1, y1, x2, y2, color, w=3):
    d.line((x1, y1, x2, y2), fill=color, width=w * S)


def text(d, xy, s, font, fill=TEXT, anchor=None):
    d.text(xy, s, font=font, fill=fill, anchor=anchor)


def draw_step(d, points, high_y, low_y, color):
    for i in range(len(points) - 1):
        t0, v0 = points[i]
        t1, v1 = points[i + 1]
        y0 = high_y if v0 else low_y
        y1 = high_y if v1 else low_y
        line(d, tx(t0), y0, tx(t1), y0, color)
        if y0 != y1:
            line(d, tx(t1), y0, tx(t1), y1, color)


def main():
    img = Image.new("RGB", (W * S, H * S), BG)
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W * S, 100 * S), fill=PANEL)

    text(d, (40 * S, 26 * S), "I2C 写 OLED 命令 0xAF — SDA / SCL 仿真波形", f_title)
    text(d, (42 * S, 70 * S),
         "START + 0x78(写) + ACK + 0x00(控制) + ACK + 0xAF(display on) + ACK + STOP",
         f_sub, MUTED)

    # 时间网格
    for us in range(0, 81, 5):
        x = tx(us)
        color = (52, 62, 80) if us % 10 == 0 else GRID
        line(d, x, TOP - 20 * S, x, BOT + 10 * S, color, 1)
        if us % 10 == 0:
            text(d, (x, BOT + 22 * S), f"{us}", f_small, MUTED, anchor="ma")

    # 面板和通道名
    d.rectangle((LEFT, 140 * S, W * S - RIGHT, BOT + 5 * S), outline=(54, 64, 82), width=2 * S)
    text(d, (tx(80) + 10 * S, BOT + 22 * S), "us", f_small, MUTED, anchor="lm")
    text(d, (40 * S, (SCL_HIGH + SCL_LOW) // 2), "SCL", f_lab, SCL_COLOR, anchor="lm")
    text(d, (40 * S, (SDA_HIGH + SDA_LOW) // 2), "SDA", f_lab, SDA_COLOR, anchor="lm")
    text(d, (40 * S, 180 * S), "400 kHz", f_small, MUTED, anchor="lm")

    # I2C 时序
    start = 5.0
    bit0 = 5.4
    bit_period = 2.5
    high_delay = 1.15
    sda_delay = 0.35
    sample_delay = 1.75

    addr = [int(b) for b in f"{0x78:08b}"]
    ctrl = [int(b) for b in f"{0x00:08b}"]
    data = [int(b) for b in f"{0xAF:08b}"]
    bits = addr + [0] + ctrl + [0] + data + [0]
    labels = [str(b) for b in addr] + ["A"] + [str(b) for b in ctrl] + ["A"] + [str(b) for b in data] + ["A"]

    scl = [(0.0, 1), (bit0, 0)]
    sda = [(0.0, 1), (start, 0)]

    # 每个 bit：SCL 低 -> SDA 变化 -> SCL 高
    for i, b in enumerate(bits):
        t = bit0 + i * bit_period
        scl.append((t, 0))
        scl.append((t + high_delay, 1))
        sda.append((t + sda_delay, b))
        sda.append((t + bit_period, b))

    # STOP：SCL 低，SDA 低，SCL 高，SDA 高
    end = bit0 + len(bits) * bit_period
    scl.append((end, 0))
    sda.append((end, 0))
    scl.append((end + 1.1, 1))
    sda.append((end + 1.7, 1))
    scl.append((T_MAX, 1))
    sda.append((T_MAX, 1))

    # 去掉重复/乱序点
    def clean(points):
        out = []
        for t, v in points:
            if out and abs(out[-1][0] - t) < 1e-9:
                out[-1] = (t, v)
            elif out and t < out[-1][0]:
                continue
            else:
                out.append((t, v))
        return out

    scl = clean(scl)
    sda = clean(sda)

    draw_step(d, scl, SCL_HIGH, SCL_LOW, SCL_COLOR)
    draw_step(d, sda, SDA_HIGH, SDA_LOW, SDA_COLOR)

    # START / STOP 标记
    line(d, tx(start), 190 * S, tx(start), 560 * S, START_COLOR, 2)
    text(d, (tx(start) + 8 * S, 190 * S), "START", f_small, START_COLOR)
    stop_t = end + 1.7
    line(d, tx(stop_t), 190 * S, tx(stop_t), 560 * S, START_COLOR, 2)
    text(d, (tx(stop_t) + 8 * S, 190 * S), "STOP", f_small, START_COLOR)

    # 位标注
    for i, (b, lab) in enumerate(zip(bits, labels)):
        t = bit0 + i * bit_period
        x = tx(t + bit_period / 2)
        text(d, (x, 192 * S), lab, f_bit, ACK_COLOR if lab == "A" else TEXT, anchor="ma")
        # 采样点
        sx = tx(t + sample_delay)
        sy = SDA_HIGH if b else SDA_LOW
        d.ellipse((sx - 4 * S, sy - 4 * S, sx + 4 * S, sy + 4 * S),
                  fill=BG, outline=ACK_COLOR, width=2 * S)

    # 分组标注
    groups = [
        (0, 8, "地址 0x78（写）", (80, 170, 255)),
        (9, 17, "控制字节 0x00", (170, 130, 255)),
        (18, 26, "数据 0xAF", (255, 130, 200)),
    ]
    for a, b, label, color in groups:
        x1 = tx(bit0 + a * bit_period)
        x2 = tx(bit0 + (b + 1) * bit_period)
        y = 120 * S
        d.rectangle((x1 + 3 * S, y - 22 * S, x2 - 3 * S, y + 4 * S),
                    outline=color, width=2 * S)
        text(d, ((x1 + x2) // 2, y - 9 * S), label, f_cn_small, color, anchor="mm")

    # 说明
    text(d, (LEFT, 650 * S),
         "SCL = 400 kHz（周期 2.5 us）    SDA 在 SCL 低电平期间变化，在 SCL 高电平期间被采样",
         f_cn, TEXT)
    text(d, (LEFT, 682 * S),
         "采样点：绿色小圆圈。地址 0x3C 的写地址为 0x78；ACK 由从机拉低 SDA。",
         f_cn_small, MUTED)
    text(d, (LEFT, 716 * S),
         "注意：Keil 虚拟逻辑分析仪通过 SWD 读变量/寄存器，采样率不足以还原 400 kHz 真实 I2C 引脚波形；",
         f_cn_small, NOTE)
    text(d, (LEFT, 744 * S),
         "本图是按本工程 I2C 时序重建的仿真波形，用于原理说明；真实测量请用 Saleae/PulseView 或示波器。",
         f_cn_small, NOTE)

    OUT.parent.mkdir(exist_ok=True)
    img.resize((W, H), Image.LANCZOS).save(OUT)
    print(f"written {OUT}")


if __name__ == "__main__":
    main()
