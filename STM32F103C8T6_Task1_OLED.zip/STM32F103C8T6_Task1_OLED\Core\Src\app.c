/**
  ******************************************************************************
  * @file    app.c
  * @brief   任务一界面与业务逻辑。
  *
  * 页面：
  *   1/4 学号 + 姓名
  *   2/4 AHT20 温度 + 湿度
  *   3/4 长字符串软件跑马灯（支持任意长度）
  *   4/4 SSD1306 硬件水平滚动演示（0x26/0x27/0x2F）
  *
  * 每页自动停留一段时间；PA0 按下可立即切页。
  ******************************************************************************
  */
#include "app.h"
#include "app_config.h"
#include "aht20.h"
#include "board.h"
#include "bsp_uart.h"
#include "main.h"
#include "oled.h"
#include <string.h>

typedef enum
{
    PAGE_INFO = 0,
    PAGE_SENSOR,
    PAGE_SOFT_SCROLL,
#if APP_USE_HW_SCROLL_PAGE
    PAGE_HW_SCROLL,
#endif
    PAGE_COUNT
} app_page_t;

static app_page_t s_page = PAGE_INFO;
static uint32_t s_page_tick;
static uint32_t s_anim_tick;
static uint32_t s_sensor_tick;
static uint32_t s_led_tick;
static uint32_t s_oled_retry_tick;
static uint16_t s_marquee_offset;

static bool s_oled_ok;
static uint8_t s_oled_fail;
static bool s_sensor_ok;
static aht20_data_t s_sensor;
static bool s_dirty = true;

/* ========================== 小工具 ========================== */

static void page_label(char *buf, app_page_t page)
{
    buf[0] = (char)('1' + (char)page);
    buf[1] = '/';
    buf[2] = (char)('0' + (char)PAGE_COUNT);
    buf[3] = '\0';
}

static void draw_header(const char *title, app_page_t page)
{
    char label[4];

    page_label(label, page);
    oled_draw_text(0, 1, title, OLED_FONT_6X8);
    oled_draw_text(104, 1, label, OLED_FONT_6X8);
}

/* 把 v10（实际值 x10）格式化成 "-12.3" */
static void format_fixed1(char *out, int32_t v10)
{
    char tmp[10];
    uint8_t n = 0;
    uint32_t a;

    if (v10 < 0)
    {
        *out++ = '-';
        a = (uint32_t)(-v10);
    }
    else
    {
        a = (uint32_t)v10;
    }

    tmp[n++] = (char)('0' + (a % 10U));
    a /= 10U;
    tmp[n++] = '.';
    tmp[n++] = (char)('0' + (a % 10U));
    a /= 10U;

    if (a == 0U)
    {
        tmp[n++] = '0';
    }
    else
    {
        while ((a > 0U) && (n < sizeof(tmp)))
        {
            tmp[n++] = (char)('0' + (a % 10U));
            a /= 10U;
        }
    }

    while (n > 0U)
    {
        *out++ = tmp[--n];
    }
    *out = '\0';
}

static int32_t fixed1_from_float(float value)
{
    return (int32_t)(value * 10.0f + ((value >= 0.0f) ? 0.5f : -0.5f));
}

#if APP_USE_UART_LOG
static void log_fixed1(const char *name, int32_t v10)
{
    uint32_t a = (v10 < 0) ? (uint32_t)(-v10) : (uint32_t)v10;

    bsp_uart_puts(name);
    if (v10 < 0)
    {
        bsp_uart_putc('-');
    }
    bsp_uart_put_u32(a / 10U);
    bsp_uart_putc('.');
    bsp_uart_put_u32(a % 10U);
}
#endif

/* ========================== OLED 错误恢复 ========================== */

static void app_oled_fail(void)
{
    if (++s_oled_fail >= 3U)
    {
        s_oled_fail = 0U;
        if (oled_init())
        {
            s_dirty = true;
        }
        else
        {
            s_oled_ok = false;
            s_oled_retry_tick = HAL_GetTick();
        }
    }
}

static bool app_refresh_full(void)
{
    if (oled_refresh())
    {
        s_oled_fail = 0U;
        return true;
    }

    s_dirty = true;
    app_oled_fail();
    return false;
}

/* ========================== 页面绘制 ========================== */

static void app_render_info(void)
{
    uint16_t id_len = (uint16_t)strlen(STUDENT_ID);

    oled_clear();
    draw_header("STUDENT ID", PAGE_INFO);

    if (id_len <= 8U)
    {
        /* 8 位学号用 8x16 字库放大 2 倍，正好 128 像素宽 */
        uint16_t width = (uint16_t)(id_len * 16U);
        int16_t x = (int16_t)(((int16_t)OLED_WIDTH - (int16_t)width) / 2);
        if (x < 0)
        {
            x = 0;
        }
        oled_draw_text_scaled(x, 12, STUDENT_ID, OLED_FONT_8X16, 2U, 2U);

        width = oled_text_width(STUDENT_NAME, OLED_FONT_16X16);
        x = (int16_t)(((int16_t)OLED_WIDTH - (int16_t)width) / 2);
        if (x < 0)
        {
            x = 0;
        }
        oled_draw_text(x, 47, STUDENT_NAME, OLED_FONT_16X16);
    }
    else
    {
        /* 9~12 位学号：8x16 居中显示，下面单独一行放姓名 */
        uint16_t width = (uint16_t)(id_len * 8U);
        int16_t x = (int16_t)(((int16_t)OLED_WIDTH - (int16_t)width) / 2);
        if (x < 0)
        {
            x = 0;
        }
        oled_draw_text(x, 14, STUDENT_ID, OLED_FONT_8X16);

        oled_draw_text(0, 36, "姓名", OLED_FONT_16X16);
        oled_draw_text(40, 36, STUDENT_NAME, OLED_FONT_16X16);
        oled_draw_text(0, 56, "CQJTU  IOT205", OLED_FONT_6X8);
    }
}

static void app_render_sensor(void)
{
    oled_clear();
    draw_header("AHT20", PAGE_SENSOR);

    if (!s_sensor_ok)
    {
        oled_draw_text_center(18, "未检测到传感器", OLED_FONT_16X16);
        oled_draw_text_center(40, "请检查 SDA/SCL", OLED_FONT_16X16);
        oled_draw_text(0, 56, "AHT20 ERROR", OLED_FONT_6X8);
        return;
    }

    int32_t t10 = fixed1_from_float(s_sensor.temperature);
    int32_t h10 = fixed1_from_float(s_sensor.humidity);
    char tbuf[12];
    char hbuf[12];

    format_fixed1(tbuf, t10);
    format_fixed1(hbuf, h10);

    oled_draw_text(0, 14, "温度", OLED_FONT_16X16);
    oled_draw_rect(34, 12, 94, 20, 1);
    oled_draw_text(38, 14, tbuf, OLED_FONT_8X16);
    oled_draw_text((int16_t)(38 + (int16_t)strlen(tbuf) * 8 + 1),
                   14, "℃", OLED_FONT_16X16);

    oled_draw_text(0, 36, "湿度", OLED_FONT_16X16);
    oled_draw_rect(34, 34, 94, 20, 1);
    oled_draw_text(38, 36, hbuf, OLED_FONT_8X16);
    oled_draw_text((int16_t)(38 + (int16_t)strlen(hbuf) * 8 + 1),
                   36, "%", OLED_FONT_8X16);

    oled_draw_text(0, 56, s_sensor.crc_ok ? "CRC OK" : "CRC ERR",
                   OLED_FONT_6X8);
    oled_draw_text(76, 56, "AHT20", OLED_FONT_6X8);
}

static void app_draw_soft_band(void)
{
    uint16_t width = oled_text_width(MARQUEE_TEXT, OLED_FONT_16X16);
    uint16_t period = (uint16_t)(width + 32U);
    uint16_t offset = (uint16_t)(s_marquee_offset % period);
    int16_t x = (int16_t)((int16_t)OLED_WIDTH - (int16_t)offset);

    /* 只清 y=16..31，对应 page2/page3 */
    oled_fill_rect(0, 16, 128, 16, 0);
    oled_draw_text(x, 16, MARQUEE_TEXT, OLED_FONT_16X16);
    oled_draw_text((int16_t)(x + (int16_t)width + 32),
                   16, MARQUEE_TEXT, OLED_FONT_16X16);
}

static void app_render_soft_scroll(void)
{
    oled_clear();
    draw_header("MARQUEE", PAGE_SOFT_SCROLL);
    oled_draw_hline(0, 10, 128, 1);
    oled_draw_hline(0, 34, 128, 1);

    oled_draw_text_center(40, SCHOOL_NAME, OLED_FONT_16X16);
    oled_draw_text(0, 56, "I2C 400kHz", OLED_FONT_6X8);

    s_marquee_offset = 0U;
    app_draw_soft_band();
}

#if APP_USE_HW_SCROLL_PAGE
static void app_render_hw_scroll(void)
{
    oled_clear();
    oled_draw_text_center(12, HW_SCROLL_LINE1, OLED_FONT_16X16);
    oled_draw_text_center(38, HW_SCROLL_LINE2, OLED_FONT_16X16);

    if (app_refresh_full())
    {
        (void)oled_hw_scroll_start(true, 0U, 7U, 0x00U);
    }
}
#endif

static void app_render(void)
{
    switch (s_page)
    {
        case PAGE_INFO:
            app_render_info();
            (void)app_refresh_full();
            break;

        case PAGE_SENSOR:
            app_render_sensor();
            (void)app_refresh_full();
            break;

        case PAGE_SOFT_SCROLL:
            app_render_soft_scroll();
            (void)app_refresh_full();
            break;

#if APP_USE_HW_SCROLL_PAGE
        case PAGE_HW_SCROLL:
            app_render_hw_scroll();
            break;
#endif

        default:
            break;
    }
}

/* ========================== 业务逻辑 ========================== */

static void app_read_sensor(void)
{
    aht20_data_t data;

    if (aht20_read(&data))
    {
        s_sensor = data;
        s_sensor_ok = true;
        s_dirty = true;

#if APP_USE_UART_LOG
        log_fixed1("AHT20: T=", fixed1_from_float(data.temperature));
        bsp_uart_puts(" C, RH=");
        log_fixed1("", fixed1_from_float(data.humidity));
        bsp_uart_puts(" %, CRC=");
        bsp_uart_puts(data.crc_ok ? "OK" : "ERR");
        bsp_uart_newline();
#endif
    }
    else
    {
        if (s_sensor_ok)
        {
            s_sensor_ok = false;
            s_dirty = true;
        }

#if APP_USE_UART_LOG
        bsp_uart_puts("AHT20 read failed, status=");
        bsp_uart_put_hex8(aht20_last_status());
        bsp_uart_newline();
#endif
    }
}

static uint32_t app_page_duration(app_page_t page)
{
    switch (page)
    {
        case PAGE_INFO:
            return PAGE_INFO_MS;
        case PAGE_SENSOR:
            return PAGE_SENSOR_MS;
        case PAGE_SOFT_SCROLL:
            return PAGE_SOFT_SCROLL_MS;
#if APP_USE_HW_SCROLL_PAGE
        case PAGE_HW_SCROLL:
            return PAGE_HW_SCROLL_MS;
#endif
        default:
            return 5000U;
    }
}

static void app_enter_page(app_page_t page)
{
#if APP_USE_HW_SCROLL_PAGE
    if (s_page == PAGE_HW_SCROLL)
    {
        oled_hw_scroll_stop();
    }
#endif

    s_page = page;
    s_page_tick = HAL_GetTick();
    s_anim_tick = s_page_tick;
    s_marquee_offset = 0U;
    s_dirty = true;

    if (page == PAGE_SENSOR)
    {
        /* 进入页面立即采样一次 */
        s_sensor_tick = s_page_tick - AHT20_PERIOD_MS;
    }
}

static void app_next_page(void)
{
    app_page_t next = (app_page_t)(((uint8_t)s_page + 1U) %
                                   (uint8_t)PAGE_COUNT);
    app_enter_page(next);
}

#if APP_USE_KEY_PA0
static bool key_take_press(void)
{
    static uint8_t stable = 1U;
    static uint8_t last = 1U;
    static uint32_t change_tick;

    uint8_t raw = (HAL_GPIO_ReadPin(KEY_PORT, KEY_PIN) == GPIO_PIN_RESET)
                      ? 0U : 1U;
    uint32_t now = HAL_GetTick();

    if (raw != last)
    {
        last = raw;
        change_tick = now;
    }

    if (((now - change_tick) > 20U) && (raw != stable))
    {
        stable = raw;
        if (stable == 0U)
        {
            return true;
        }
    }

    return false;
}
#endif

static void app_oled_retry(void)
{
    uint32_t now = HAL_GetTick();

    if ((now - s_oled_retry_tick) < 2000U)
    {
        return;
    }

    s_oled_retry_tick = now;

    if (oled_init())
    {
        s_oled_ok = true;
        app_enter_page(PAGE_INFO);
    }
}

static void app_update_soft_band(void)
{
    app_draw_soft_band();

    if (oled_refresh_pages(2U, 3U))
    {
        s_oled_fail = 0U;
    }
    else
    {
        s_dirty = true;
        app_oled_fail();
    }
}

/* ========================== 对外接口 ========================== */

void app_init(void)
{
    /* OLED 上电较慢，最多探测两次 */
    for (uint8_t attempt = 0; attempt < 2U; ++attempt)
    {
        if (oled_init())
        {
            s_oled_ok = true;
            break;
        }
        HAL_Delay(100);
    }

#if APP_USE_UART_LOG
    bsp_uart_puts("OLED: ");
    if (s_oled_ok)
    {
        bsp_uart_puts("found at ");
        bsp_uart_put_hex8(oled_address());
        bsp_uart_newline();
    }
    else
    {
        bsp_uart_puts("NOT FOUND (check PB6/PB7, 0x3C/0x3D)\r\n");
    }
#endif

    if (s_oled_ok)
    {
        oled_clear();
        oled_draw_text_center(4, "STM32F103", OLED_FONT_8X16);
        oled_draw_text_center(22, "OLED + AHT20", OLED_FONT_6X8);
        oled_draw_text_center(36, "任务一", OLED_FONT_16X16);
        oled_draw_text_center(56, "I2C 400kHz", OLED_FONT_6X8);
        (void)app_refresh_full();
        HAL_Delay(1200);
    }

    s_sensor_ok = aht20_init();

#if APP_USE_UART_LOG
    bsp_uart_puts("AHT20: ");
    bsp_uart_puts(s_sensor_ok ? "init OK\r\n" : "init FAIL\r\n");
#endif

    if (s_sensor_ok)
    {
        app_read_sensor();
    }
    else
    {
        s_dirty = true;
    }

    app_enter_page(PAGE_INFO);

    if (!s_oled_ok)
    {
        s_oled_retry_tick = HAL_GetTick();
    }
}

void app_run(void)
{
    for (;;)
    {
        uint32_t now = HAL_GetTick();

        if (!s_oled_ok)
        {
            app_oled_retry();

            if ((now - s_led_tick) >= 200U)
            {
                s_led_tick = now;
                LED_TOGGLE();
            }

            HAL_Delay(10);
            continue;
        }

#if APP_USE_KEY_PA0
        if (key_take_press())
        {
            app_next_page();
            now = HAL_GetTick();
        }
#endif

        if ((now - s_page_tick) >= app_page_duration(s_page))
        {
            app_next_page();
            now = HAL_GetTick();
        }

        if ((s_page == PAGE_SENSOR) &&
            ((now - s_sensor_tick) >= AHT20_PERIOD_MS))
        {
            s_sensor_tick = now;
            app_read_sensor();
        }

        if ((s_page == PAGE_SOFT_SCROLL) &&
            ((now - s_anim_tick) >= APP_MARQUEE_PERIOD_MS))
        {
            s_anim_tick = now;
            s_marquee_offset = (uint16_t)(s_marquee_offset +
                                          APP_MARQUEE_STEP_PX);
            app_update_soft_band();
        }

        if (s_dirty)
        {
            s_dirty = false;
            app_render();
        }

        if ((now - s_led_tick) >= 500U)
        {
            s_led_tick = now;
            LED_TOGGLE();
        }

        HAL_Delay(2);
    }
}
