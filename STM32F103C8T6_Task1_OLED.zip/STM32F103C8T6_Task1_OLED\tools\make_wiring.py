#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 docs/wiring.png 接线示意图（不需要额外库，Pillow 即可）。"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "docs" / "wiring.png"

W, H = 1280, 820
BG = (16, 18, 24)
PANEL = (28, 32, 42)
BOARD = (18, 58, 38)
OLED = (14, 28, 44)
SENSOR = (44, 26, 20)
TEXT = (232, 236, 244)
MUTED = (160, 168, 184)
RED = (235, 80, 80)
GRAY = (150, 156, 168)
YELLOW = (245, 205, 70)
CYAN = (70, 210, 225)
GREEN = (90, 220, 140)

FONT = r"C:\Windows\Fonts\simhei.ttf"
f_title = ImageFont.truetype(FONT, 34)
f_big = ImageFont.truetype(FONT, 24)
f_mid = ImageFont.truetype(FONT, 20)
f_small = ImageFont.truetype(FONT, 17)


def text(draw, xy, s, font, fill=TEXT, anchor=None):
    draw.text(xy, s, font=font, fill=fill, anchor=anchor)


def wire(draw, points, color, width=6):
    draw.line(points, fill=color, width=width, joint="curve")
    for p in points:
        draw.ellipse((p[0] - width // 2, p[1] - width // 2,
                      p[0] + width // 2, p[1] + width // 2), fill=color)


def main():
    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)

    text(d, (40, 28), "STM32F103C8T6 + 0.96\" OLED + AHT20 接线图", f_title)
    text(d, (42, 72), "I2C1: PB6=SCL, PB7=SDA, 400 kHz  |  OLED 0x3C/0x3D, AHT20 0x38  |  全部 3.3V 供电",
         f_small, MUTED)

    # 开发板
    bx, by, bw, bh = 60, 130, 360, 590
    d.rounded_rectangle((bx, by, bx + bw, by + bh), radius=18, fill=BOARD,
                        outline=(80, 160, 110), width=3)
    text(d, (bx + 24, by + 20), "STM32F103C8T6", f_big)
    text(d, (bx + 24, by + 52), "Blue Pill / 最小系统板", f_small, MUTED)
    text(d, (bx + 24, by + 90), "3.3V 逻辑", f_mid, GREEN)
    text(d, (bx + 24, by + 120), "BOOT0 = 0", f_small, MUTED)
    text(d, (bx + 24, by + 146), "复位后从 Flash 启动", f_small, MUTED)

    # 板右侧引脚
    pins = [
        ("3.3V", 230, RED),
        ("GND", 286, GRAY),
        ("PB6 / SCL", 350, YELLOW),
        ("PB7 / SDA", 430, CYAN),
        ("PA9 / TX", 510, GREEN),
        ("PA10 / RX", 560, GREEN),
        ("PA0 / KEY", 620, MUTED),
    ]
    pin_xy = {}
    for name, y, color in pins:
        d.rounded_rectangle((bx + bw - 8, y - 12, bx + bw + 8, y + 12),
                            radius=5, fill=color)
        text(d, (bx + bw - 30, y), name, f_small, TEXT, anchor="rm")
        pin_xy[name] = (bx + bw + 8, y)

    # I2C 总线两条竖线
    scl_x, sda_x = 610, 668
    vcc_x, gnd_x = 520, 556

    wire(d, [pin_xy["3.3V"], (vcc_x, 230)], RED)
    wire(d, [(vcc_x, 220), (vcc_x, 525)], RED)
    wire(d, [pin_xy["GND"], (gnd_x, 286)], GRAY)
    wire(d, [(gnd_x, 255), (gnd_x, 560)], GRAY)
    wire(d, [pin_xy["PB6 / SCL"], (scl_x, 350)], YELLOW)
    wire(d, [(scl_x, 290), (scl_x, 595)], YELLOW)
    wire(d, [pin_xy["PB7 / SDA"], (sda_x, 430)], CYAN)
    wire(d, [(sda_x, 325), (sda_x, 630)], CYAN)

    # OLED
    ox, oy, ow, oh = 820, 130, 400, 245
    d.rounded_rectangle((ox, oy, ox + ow, oy + oh), radius=18, fill=OLED,
                        outline=(90, 140, 220), width=3)
    text(d, (ox + 54, oy + 18), "0.96\" OLED", f_big)
    text(d, (ox + 54, oy + 50), "SSD1306  128x64  I2C", f_small, MUTED)
    text(d, (ox + 54, 220), "VCC   ->  3.3V", f_small, RED, anchor="lm")
    text(d, (ox + 54, 255), "GND   ->  GND", f_small, GRAY, anchor="lm")
    text(d, (ox + 54, 290), "SCL   ->  PB6", f_small, YELLOW, anchor="lm")
    text(d, (ox + 54, 325), "SDA   ->  PB7", f_small, CYAN, anchor="lm")
    text(d, (ox + 54, 350), "地址：0x3C（少数 0x3D）", f_small, MUTED)

    for y, color in [(220, RED), (255, GRAY), (290, YELLOW), (325, CYAN)]:
        d.ellipse((ox - 8, y - 8, ox + 8, y + 8), fill=color, outline=BG, width=2)

    # AHT20
    ax, ay, aw, ah = 820, 445, 400, 240
    d.rounded_rectangle((ax, ay, ax + aw, ay + ah), radius=18, fill=SENSOR,
                        outline=(210, 120, 90), width=3)
    text(d, (ax + 54, ay + 18), "AHT20", f_big)
    text(d, (ax + 54, ay + 50), "温湿度传感器  I2C", f_small, MUTED)
    text(d, (ax + 54, 525), "VCC   ->  3.3V", f_small, RED, anchor="lm")
    text(d, (ax + 54, 560), "GND   ->  GND", f_small, GRAY, anchor="lm")
    text(d, (ax + 54, 595), "SCL   ->  PB6", f_small, YELLOW, anchor="lm")
    text(d, (ax + 54, 630), "SDA   ->  PB7", f_small, CYAN, anchor="lm")
    text(d, (ax + 54, 658), "地址：0x38", f_small, MUTED)

    for y, color in [(525, RED), (560, GRAY), (595, YELLOW), (630, CYAN)]:
        d.ellipse((ax - 8, y - 8, ax + 8, y + 8), fill=color, outline=BG, width=2)

    # 分支到 OLED / AHT20
    wire(d, [(vcc_x, 220), (ox, 220)], RED, 5)
    wire(d, [(vcc_x, 525), (ax, 525)], RED, 5)
    wire(d, [(gnd_x, 255), (ox, 255)], GRAY, 5)
    wire(d, [(gnd_x, 560), (ax, 560)], GRAY, 5)
    wire(d, [(scl_x, 290), (ox, 290)], YELLOW, 5)
    wire(d, [(scl_x, 595), (ax, 595)], YELLOW, 5)
    wire(d, [(sda_x, 325), (ox, 325)], CYAN, 5)
    wire(d, [(sda_x, 630), (ax, 630)], CYAN, 5)

    # 节点圆点
    for x, y, color in [(vcc_x, 220, RED), (gnd_x, 255, GRAY),
                        (scl_x, 290, YELLOW), (sda_x, 325, CYAN),
                        (vcc_x, 525, RED), (gnd_x, 560, GRAY),
                        (scl_x, 595, YELLOW), (sda_x, 630, CYAN)]:
        d.ellipse((x - 8, y - 8, x + 8, y + 8), fill=color, outline=BG, width=2)

    # 底部提示
    tip_y = 720
    d.rounded_rectangle((40, tip_y, W - 40, H - 28), radius=14, fill=PANEL)
    text(d, (64, tip_y + 18), "注意：", f_mid, (255, 190, 90))
    text(d, (134, tip_y + 18),
         "OLED 和 AHT20 模块通常自带 4.7k 上拉；若没有，SCL/SDA 各接 4.7k 到 3.3V。"
         " 杜邦线尽量短，电源共地。", f_small, TEXT)
    text(d, (64, tip_y + 50),
         "调试串口（可选）：PA9(TX)->USB-TTL RX，PA10(RX)->USB-TTL TX，GND->GND，115200。"
         " 按键（可选）：PA0->GND。", f_small, MUTED)

    OUT.parent.mkdir(exist_ok=True)
    img.save(OUT)
    print(f"written {OUT}")


if __name__ == "__main__":
    main()
