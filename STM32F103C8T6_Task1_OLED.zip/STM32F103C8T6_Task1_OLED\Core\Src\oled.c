/**
  ******************************************************************************
  * @file    oled.c
  * @brief   SSD1306 128x64 I2C OLED 驱动。
  *
  * 显存布局：oled_buffer[page * 128 + x]，每字节纵向 8 像素，LSB 在上。
  * 这样与 SSD1306 GDDRAM 完全一致，整屏刷新只需一次 0x40 数据流。
  *
  * 本文件同时支持：
  *   - 6x8 / 8x16 ASCII 字库
  *   - 16x16 汉字字库（UTF-8 解码）
  *   - 局部页刷新（跑马灯只刷 2 页，降低 I2C 占用）
  *   - SSD1306 硬件水平滚动命令
  ******************************************************************************
  */
#include "oled.h"
#include "oled_font.h"
#include "app_config.h"
#include "bsp_i2c.h"
#include <string.h>

uint8_t oled_buffer[OLED_BUFFER_SIZE];

static uint8_t s_addr7;
static uint8_t s_tx[1U + OLED_BUFFER_SIZE];

static bool oled_cmd(uint8_t cmd)
{
    uint8_t buf[2] = {0x00U, cmd};
    if (s_addr7 == 0U)
    {
        return false;
    }
    return bsp_i2c_write(s_addr7, buf, sizeof(buf), 20);
}

static bool oled_cmds(const uint8_t *cmds, uint8_t len)
{
    uint8_t buf[16];

    if ((cmds == NULL) || (len == 0U) || (len > (sizeof(buf) - 1U)) ||
        (s_addr7 == 0U))
    {
        return false;
    }

    buf[0] = 0x00U;                 /* Co=0, D/C#=0：后续全是命令 */
    memcpy(&buf[1], cmds, len);
    return bsp_i2c_write(s_addr7, buf, (uint16_t)(len + 1U), 30);
}

bool oled_init(void)
{
    static const uint8_t init_cmds[] =
    {
        0xAEU,              /* display off */
        0xD5U, 0x80U,       /* clock divide */
        0xA8U, 0x3FU,       /* multiplex 64 */
        0xD3U, 0x00U,       /* display offset 0 */
        0x40U,              /* start line 0 */
        0x8DU, 0x14U,       /* charge pump on */
        0x20U, 0x00U,       /* horizontal addressing */
        0xA1U,              /* segment remap */
        0xC8U,              /* COM scan dec */
        0xDAU, 0x12U,       /* COM pins */
        0x81U, 0xCFU,       /* contrast */
        0xD9U, 0xF1U,       /* pre-charge */
        0xDBU, 0x40U,       /* VCOMH */
        0xA4U,              /* resume RAM content */
        0xA6U,              /* normal (not inverse) */
        0x2EU,              /* stop scroll */
        0xAFU               /* display on */
    };

    s_addr7 = 0U;

    if (bsp_i2c_probe(OLED_I2C_ADDR))
    {
        s_addr7 = OLED_I2C_ADDR;
    }
    else if (bsp_i2c_probe(OLED_I2C_ADDR_ALT))
    {
        s_addr7 = OLED_I2C_ADDR_ALT;
    }
    else
    {
        return false;
    }

    HAL_Delay(50);

    for (uint16_t i = 0; i < sizeof(init_cmds); ++i)
    {
        if (!oled_cmd(init_cmds[i]))
        {
            s_addr7 = 0U;
            return false;
        }
    }

    HAL_Delay(100);
    return true;
}

void oled_clear(void)
{
    memset(oled_buffer, 0, sizeof(oled_buffer));
}

void oled_draw_pixel(int16_t x, int16_t y, uint8_t color)
{
    if ((x < 0) || (x >= (int16_t)OLED_WIDTH) ||
        (y < 0) || (y >= (int16_t)OLED_HEIGHT))
    {
        return;
    }

    uint16_t index = (uint16_t)((y / 8) * (int16_t)OLED_WIDTH + x);
    uint8_t mask = (uint8_t)(1U << (y & 7));

    if (color != 0U)
    {
        oled_buffer[index] |= mask;
    }
    else
    {
        oled_buffer[index] &= (uint8_t)~mask;
    }
}

void oled_fill_rect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color)
{
    int16_t x0 = x;
    int16_t y0 = y;
    int16_t x1 = (int16_t)(x + w);
    int16_t y1 = (int16_t)(y + h);

    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > (int16_t)OLED_WIDTH) x1 = (int16_t)OLED_WIDTH;
    if (y1 > (int16_t)OLED_HEIGHT) y1 = (int16_t)OLED_HEIGHT;

    for (int16_t yy = y0; yy < y1; ++yy)
    {
        for (int16_t xx = x0; xx < x1; ++xx)
        {
            oled_draw_pixel(xx, yy, color);
        }
    }
}

void oled_draw_hline(int16_t x, int16_t y, int16_t w, uint8_t color)
{
    oled_fill_rect(x, y, w, 1, color);
}

void oled_draw_vline(int16_t x, int16_t y, int16_t h, uint8_t color)
{
    oled_fill_rect(x, y, 1, h, color);
}

void oled_draw_rect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color)
{
    if ((w <= 0) || (h <= 0))
    {
        return;
    }

    oled_draw_hline(x, y, w, color);
    oled_draw_hline(x, (int16_t)(y + h - 1), w, color);
    oled_draw_vline(x, y, h, color);
    oled_draw_vline((int16_t)(x + w - 1), y, h, color);
}

bool oled_refresh_pages(uint8_t first_page, uint8_t last_page)
{
    if ((s_addr7 == 0U) || (first_page > last_page) ||
        (last_page >= OLED_PAGES))
    {
        return false;
    }

    uint8_t cmds[] =
    {
        0x21U, 0x00U, (uint8_t)(OLED_WIDTH - 1U),   /* column 0..127 */
        0x22U, first_page, last_page                /* page range */
    };

    if (!oled_cmds(cmds, sizeof(cmds)))
    {
        return false;
    }

    uint16_t len = (uint16_t)(OLED_WIDTH * (last_page - first_page + 1U));
    s_tx[0] = 0x40U;                /* Co=0, D/C#=1：后续是显存数据 */
    memcpy(&s_tx[1], &oled_buffer[first_page * OLED_WIDTH], len);

    return bsp_i2c_write(s_addr7, s_tx, (uint16_t)(len + 1U), 200);
}

bool oled_refresh(void)
{
    return oled_refresh_pages(0U, OLED_PAGES - 1U);
}

static const uint8_t *font_ascii(char c, oled_font_t font,
                                 uint8_t *width, uint8_t *height)
{
    uint8_t index;

    if ((c < 0x20) || (c > 0x7E))
    {
        return NULL;
    }

    index = (uint8_t)(c - 0x20);

    switch (font)
    {
        case OLED_FONT_6X8:
            *width = 6U;
            *height = 8U;
            return oled_font6x8[index];

        case OLED_FONT_16X16:
        case OLED_FONT_8X16:
        default:
            *width = 8U;
            *height = 16U;
            return oled_font8x16[index];
    }
}

static const oled_cn_glyph_t *font_cn(uint32_t codepoint)
{
    uint16_t lo = 0U;
    uint16_t hi = oled_cn_font_count;

    while (lo < hi)
    {
        uint16_t mid = (uint16_t)(lo + (hi - lo) / 2U);
        uint32_t value = oled_cn_font[mid].codepoint;

        if (value == codepoint)
        {
            return &oled_cn_font[mid];
        }
        if (value < codepoint)
        {
            lo = (uint16_t)(mid + 1U);
        }
        else
        {
            hi = mid;
        }
    }

    return NULL;
}

static uint32_t utf8_next(const char **text)
{
    const uint8_t *s = (const uint8_t *)*text;
    uint32_t cp;
    uint8_t n;

    if (s[0] < 0x80U)
    {
        *text += 1;
        return s[0];
    }

    if ((s[0] & 0xE0U) == 0xC0U)
    {
        cp = (uint32_t)(s[0] & 0x1FU);
        n = 1U;
    }
    else if ((s[0] & 0xF0U) == 0xE0U)
    {
        cp = (uint32_t)(s[0] & 0x0FU);
        n = 2U;
    }
    else if ((s[0] & 0xF8U) == 0xF0U)
    {
        cp = (uint32_t)(s[0] & 0x07U);
        n = 3U;
    }
    else
    {
        *text += 1;
        return 0xFFFDU;
    }

    for (uint8_t i = 0; i < n; ++i)
    {
        if ((s[i + 1U] & 0xC0U) != 0x80U)
        {
            *text += 1;
            return 0xFFFDU;
        }
        cp = (cp << 6) | (uint32_t)(s[i + 1U] & 0x3FU);
    }

    *text += (n + 1U);
    return cp;
}

static void draw_glyph(int16_t x, int16_t y, uint8_t w, uint8_t h,
                       const uint8_t *data)
{
    for (uint8_t col = 0; col < w; ++col)
    {
        for (uint8_t row = 0; row < h; ++row)
        {
            uint8_t bits = data[(uint16_t)col + ((uint16_t)(row >> 3) * w)];
            if ((bits & (uint8_t)(1U << (row & 7U))) != 0U)
            {
                oled_draw_pixel((int16_t)(x + col), (int16_t)(y + row), 1U);
            }
        }
    }
}

static void draw_glyph_scaled(int16_t x, int16_t y, uint8_t w, uint8_t h,
                              const uint8_t *data, uint8_t sx, uint8_t sy)
{
    for (uint8_t col = 0; col < w; ++col)
    {
        for (uint8_t row = 0; row < h; ++row)
        {
            uint8_t bits = data[(uint16_t)col + ((uint16_t)(row >> 3) * w)];
            if ((bits & (uint8_t)(1U << (row & 7U))) != 0U)
            {
                oled_fill_rect((int16_t)(x + col * sx),
                               (int16_t)(y + row * sy), sx, sy, 1U);
            }
        }
    }
}

static uint16_t text_width_impl(const char *text, oled_font_t font, uint8_t sx)
{
    uint32_t width = 0U;

    if (text == NULL)
    {
        return 0U;
    }

    while (*text != '\0')
    {
        uint32_t cp = utf8_next(&text);

        if (cp == '\n')
        {
            continue;
        }

        if (cp < 0x80U)
        {
            uint8_t w = 0U;
            uint8_t h = 0U;
            if (font_ascii((char)cp, font, &w, &h) != NULL)
            {
                width += (uint32_t)w * sx;
            }
        }
        else
        {
            width += 16U * sx;
        }

        if (width > 60000U)
        {
            return 60000U;
        }
    }

    return (uint16_t)width;
}

uint16_t oled_text_width(const char *utf8, oled_font_t font)
{
    return text_width_impl(utf8, font, 1U);
}

uint16_t oled_text_width_scaled(const char *utf8, oled_font_t font, uint8_t sx)
{
    if (sx == 0U)
    {
        return 0U;
    }
    return text_width_impl(utf8, font, sx);
}

void oled_draw_text(int16_t x, int16_t y, const char *utf8, oled_font_t font)
{
    int16_t cx = x;
    int16_t cy = y;
    uint8_t line_height = (font == OLED_FONT_6X8) ? 8U : 16U;

    if (utf8 == NULL)
    {
        return;
    }

    while (*utf8 != '\0')
    {
        uint32_t cp = utf8_next(&utf8);

        if (cp == '\r')
        {
            continue;
        }

        if (cp == '\n')
        {
            cx = x;
            cy = (int16_t)(cy + line_height);
            continue;
        }

        if (cp < 0x80U)
        {
            uint8_t w = 0U;
            uint8_t h = 0U;
            const uint8_t *glyph = font_ascii((char)cp, font, &w, &h);

            if (glyph != NULL)
            {
                draw_glyph(cx, cy, w, h, glyph);
                cx = (int16_t)(cx + w);
            }
        }
        else
        {
            const oled_cn_glyph_t *glyph = font_cn(cp);

            if (glyph != NULL)
            {
                draw_glyph(cx, cy, 16U, 16U, glyph->data);
            }
            cx = (int16_t)(cx + 16);
        }
    }
}

void oled_draw_text_center(int16_t y, const char *utf8, oled_font_t font)
{
    uint16_t width = oled_text_width(utf8, font);
    int16_t x = (int16_t)(((int16_t)OLED_WIDTH - (int16_t)width) / 2);

    if (x < 0)
    {
        x = 0;
    }

    oled_draw_text(x, y, utf8, font);
}

void oled_draw_text_scaled(int16_t x, int16_t y, const char *utf8,
                           oled_font_t font, uint8_t sx, uint8_t sy)
{
    int16_t cx = x;
    uint8_t line_height = (font == OLED_FONT_6X8) ? 8U : 16U;

    if ((utf8 == NULL) || (sx == 0U) || (sy == 0U))
    {
        return;
    }

    while (*utf8 != '\0')
    {
        uint32_t cp = utf8_next(&utf8);

        if (cp == '\r')
        {
            continue;
        }

        if (cp == '\n')
        {
            cx = x;
            y = (int16_t)(y + line_height * sy);
            continue;
        }

        if (cp < 0x80U)
        {
            uint8_t w = 0U;
            uint8_t h = 0U;
            const uint8_t *glyph = font_ascii((char)cp, font, &w, &h);

            if (glyph != NULL)
            {
                draw_glyph_scaled(cx, y, w, h, glyph, sx, sy);
                cx = (int16_t)(cx + w * sx);
            }
        }
        else
        {
            const oled_cn_glyph_t *glyph = font_cn(cp);

            if (glyph != NULL)
            {
                draw_glyph_scaled(cx, y, 16U, 16U, glyph->data, sx, sy);
            }
            cx = (int16_t)(cx + 16 * sx);
        }
    }
}

bool oled_hw_scroll_start(bool dir_left, uint8_t start_page,
                          uint8_t end_page, uint8_t interval)
{
    if ((start_page > end_page) || (end_page >= OLED_PAGES))
    {
        return false;
    }

    uint8_t cmds[] =
    {
        0x2EU,                                  /* stop first */
        (uint8_t)(dir_left ? 0x27U : 0x26U),     /* 0x27 left, 0x26 right */
        0x00U,                                  /* dummy */
        start_page,
        (uint8_t)(interval & 0x07U),
        end_page,
        0x00U,                                  /* dummy */
        0xFFU,                                  /* end column */
        0x2FU                                   /* start scroll */
    };

    return oled_cmds(cmds, sizeof(cmds));
}

void oled_hw_scroll_stop(void)
{
    (void)oled_cmd(0x2EU);
}

uint8_t oled_address(void)
{
    return s_addr7;
}
