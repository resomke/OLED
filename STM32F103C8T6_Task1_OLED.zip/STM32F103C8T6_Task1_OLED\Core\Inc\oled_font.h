/**
  ******************************************************************************
  * @file    oled_font.h
  * @brief   点阵字库声明（由 tools/gen_font.py 自动生成）。
  *
  * 字模格式：列优先，每 8 个纵向像素组成 1 个字节，LSB 在上。
  * 8x16 ASCII：16 字节 = 8 列 x 2 页
  * 16x16 汉字：32 字节 = 16 列 x 2 页
  ******************************************************************************
  */
#ifndef OLED_FONT_H
#define OLED_FONT_H

#include <stdint.h>

typedef struct
{
    uint32_t codepoint;      /* Unicode 码点 */
    uint8_t  data[32];       /* 16x16 列优先点阵 */
} oled_cn_glyph_t;

/* ASCII 0x20..0x7E，共 95 个 */
extern const uint8_t oled_font6x8[95][6];
extern const uint8_t oled_font8x16[95][16];

/* 源代码里出现的所有非 ASCII 字符，按码点升序排列 */
extern const oled_cn_glyph_t oled_cn_font[];
extern const uint16_t oled_cn_font_count;

#endif /* OLED_FONT_H */
