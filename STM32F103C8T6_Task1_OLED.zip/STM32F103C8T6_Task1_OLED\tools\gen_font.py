#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从 Windows 的宋体/黑体生成 SSD1306 需要的 C 点阵字库。

用法（在工程根目录）：
    python tools/gen_font.py

生成：
    Core/Src/oled_font.c

说明：
    - 8x16 ASCII 用宋体 16px 渲染，6x8 小字用 Consolas 8px 渲染；
    - 16x16 汉字用宋体 16px 渲染；
    - 只收集 Core/Inc、Core/Src 里字符串字面量中出现过的汉字，
      所以 64 KB Flash 也不会被完整字库撑爆；
    - 改了 STUDENT_NAME / MARQUEE_TEXT 等中文后，重新运行本脚本，
      再编译即可。若没有 Python/Pillow，也可以把文字发给我重新生成 HEX。
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
SRC_DIRS = [ROOT / "Core" / "Inc", ROOT / "Core" / "Src"]
OUT_C = ROOT / "Core" / "Src" / "oled_font.c"

FONT_CN = Path(r"C:\Windows\Fonts\simsun.ttc")
FONT_ASCII16 = Path(r"C:\Windows\Fonts\simsun.ttc")
FONT_ASCII8 = Path(r"C:\Windows\Fonts\consola.ttf")

ASCII_START = 0x20
ASCII_END = 0x7E

# 常见标点兜底，避免代码里临时加的符号没被扫描到
EXTRA_CHARS = "，。！？：；、（）《》“”‘’℃"

# 宋体的全角标点在 16x16 单元里偏向一侧；统一把墨迹水平居中，
# 避免跑马灯里“Hello，欢迎……”出现忽大忽小的字距。
PUNCT_CENTER = set("，。！？：；、（）《》“”‘’")


def render_cell(ch: str, font_path: Path, cell_w: int, cell_h: int,
                font_px: int, threshold: int = 100) -> Image.Image:
    """把一个字符渲染到 cell_w x cell_h 的黑白单元中，尽量保留原始笔画。"""
    font = ImageFont.truetype(str(font_path), font_px)

    # 留出 padding 后从 (pad,pad) 开始绘制，再裁剪出 cell 区域。
    # 这样保留字体自身的左右边距和基线，汉字不会因为逐个居中而错位。
    pad = 8
    canvas = Image.new("L", (cell_w + 2 * pad, cell_h + 2 * pad), 0)
    ImageDraw.Draw(canvas).text((pad, pad), ch, font=font, fill=255)
    ink = canvas.getbbox()
    cell = Image.new("L", (cell_w, cell_h), 0)
    box = (pad, pad, pad + cell_w, pad + cell_h)

    if ink is None:
        return cell

    if (ink[0] >= box[0] and ink[1] >= box[1] and
            ink[2] <= box[2] and ink[3] <= box[3]):
        cell = canvas.crop(box)
    else:
        # 极少数符号/宽字符超出单元格时，整体缩小并居中，保证不丢笔画
        glyph = canvas.crop(ink)
        w, h = glyph.size
        scale = min(cell_w / w, cell_h / h)
        glyph = glyph.resize((max(1, round(w * scale)),
                              max(1, round(h * scale))), Image.LANCZOS)
        w, h = glyph.size
        cell.paste(glyph, ((cell_w - w) // 2, (cell_h - h) // 2))

    if ch in PUNCT_CENTER:
        ink2 = cell.getbbox()
        if ink2 is not None:
            shift = (cell_w - (ink2[2] - ink2[0])) // 2 - ink2[0]
            if shift != 0:
                centered = Image.new("L", (cell_w, cell_h), 0)
                centered.paste(cell, (shift, 0))
                cell = centered

    return cell.point(lambda p: 255 if p >= threshold else 0)


def cell_to_column_major(img: Image.Image) -> list[int]:
    """SSD1306 列优先：每 8 个纵向像素一个字节，LSB 在上。"""
    w, h = img.size
    out: list[int] = []
    # 先输出 page0 的 16 列，再输出 page1 的 16 列；
    # 与 oled.c 中 data[col + page * width] 的索引方式一致。
    for page in range((h + 7) // 8):
        for x in range(w):
            value = 0
            for bit in range(8):
                y = page * 8 + bit
                if y < h and img.getpixel((x, y)) > 0:
                    value |= 1 << bit
            out.append(value)
    return out


def collect_chinese() -> list[str]:
    chars: set[str] = set(EXTRA_CHARS)
    pattern = re.compile(r'"((?:\\.|[^"\\])*)"')

    for folder in SRC_DIRS:
        for path in folder.glob("*.[ch]"):
            text = path.read_text(encoding="utf-8")
            # 先去掉注释，避免把注释里的中文也收进字库
            text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
            text = re.sub(r"//[^\n]*", "", text)
            for match in pattern.finditer(text):
                literal = match.group(1)
                # 只关心非 ASCII 字符；转义序列原样跳过
                for ch in literal:
                    if ord(ch) >= 0x80:
                        chars.add(ch)

    return sorted(chars, key=ord)


def c_array(data: list[int], indent: str = "    ") -> str:
    lines = []
    for i in range(0, len(data), 16):
        lines.append(indent + ", ".join(f"0x{b:02X}" for b in data[i:i + 16]) + ",")
    return "\n".join(lines)


def main() -> int:
    for path in (FONT_CN, FONT_ASCII16, FONT_ASCII8):
        if not path.exists():
            print(f"找不到字体文件：{path}", file=sys.stderr)
            return 1

    ascii_chars = [chr(c) for c in range(ASCII_START, ASCII_END + 1)]

    font6 = []
    font8 = []
    for ch in ascii_chars:
        font6.append(cell_to_column_major(render_cell(ch, FONT_ASCII8, 6, 8, 8, 90)))
        font8.append(cell_to_column_major(render_cell(ch, FONT_ASCII16, 8, 16, 16, 100)))

    cn_chars = collect_chinese()
    cn_glyphs = []
    for ch in cn_chars:
        data = cell_to_column_major(render_cell(ch, FONT_CN, 16, 16, 16, 100))
        if len(data) != 32:
            raise RuntimeError(f"{ch} 字模长度错误：{len(data)}")
        cn_glyphs.append((ord(ch), ch, data))

    out = []
    out.append("/**")
    out.append("  ******************************************************************************")
    out.append("  * @file    oled_font.c")
    out.append("  * @brief   自动生成的点阵字库，请勿手工修改。")
    out.append("  *          重新生成：python tools/gen_font.py")
    out.append("  ******************************************************************************")
    out.append("  */")
    out.append('#include "oled_font.h"')
    out.append("")
    out.append("/* ASCII 0x20..0x7E, 6x8, 列优先 */")
    out.append("const uint8_t oled_font6x8[95][6] = {")
    for data in font6:
        out.append("    {" + ", ".join(f"0x{b:02X}" for b in data) + "},")
    out.append("};")
    out.append("")
    out.append("/* ASCII 0x20..0x7E, 8x16, 列优先 */")
    out.append("const uint8_t oled_font8x16[95][16] = {")
    for data in font8:
        out.append("    {" + ", ".join(f"0x{b:02X}" for b in data) + "},")
    out.append("};")
    out.append("")
    out.append("/* 工程字符串中出现过的汉字，按 Unicode 升序 */")
    out.append("const oled_cn_glyph_t oled_cn_font[] = {")
    for codepoint, ch, data in cn_glyphs:
        out.append(f"    {{0x{codepoint:04X}U, {{")
        out.append(c_array(data, "        "))
        out.append(f"    }}}}, /* {ch} */")
    out.append("};")
    out.append("")
    out.append("const uint16_t oled_cn_font_count = "
               "(uint16_t)(sizeof(oled_cn_font) / sizeof(oled_cn_font[0]));")
    out.append("")

    OUT_C.write_text("\n".join(out), encoding="utf-8", newline="\n")
    print(f"生成 {OUT_C}")
    print(f"ASCII: 95 x 2, 汉字: {len(cn_glyphs)} 个")
    print("汉字：" + "".join(ch for _, ch, _ in cn_glyphs))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
