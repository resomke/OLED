/**
  ******************************************************************************
  * @file    main.c
  * @brief   任务一：STM32F103C8T6 + SSD1306 I2C OLED + AHT20
  *
  * 功能：
  *   1) 显示学号、姓名；
  *   2) 显示 AHT20 温度和湿度；
  *   3) 长字符串软件跑马灯（任意长度，全屏显存 + I2C 局刷）；
  *   4) 附加：SSD1306 硬件水平滚动演示页。
  *
  * 默认时钟：HSE 8 MHz -> PLL x9 = 72 MHz；HSE 不起振时自动降级为
  * HSI/2 x16 = 64 MHz，保证最小系统板没有晶振也能跑。
  ******************************************************************************
  */
#include "main.h"
#include "app.h"
#include "app_config.h"
#include "board.h"
#include "bsp_i2c.h"
#include "bsp_uart.h"

static void MX_GPIO_Init(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();

    bsp_i2c_init();

#if APP_USE_UART_LOG
    bsp_uart_init();
    bsp_uart_puts("\r\n=== STM32F103C8T6 Task1: OLED + AHT20 ===\r\n");
    bsp_uart_puts("SYSCLK = ");
    bsp_uart_put_u32(HAL_RCC_GetHCLKFreq());
    bsp_uart_puts(" Hz, PCLK1 = ");
    bsp_uart_put_u32(HAL_RCC_GetPCLK1Freq());
    bsp_uart_puts(" Hz\r\n");
    bsp_uart_puts("I2C1: PB6=SCL, PB7=SDA, 400 kHz\r\n");
#endif

    app_init();
    app_run();

    while (1)
    {
    }
}

/**
  * @brief 系统时钟：优先 72 MHz(HSE)，失败则 64 MHz(HSI)。
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    /* 先尝试外部 8 MHz 晶振，PLL x9 = 72 MHz */
    osc.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState = RCC_HSE_ON;
    osc.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL = RCC_PLL_MUL9;

    if (HAL_RCC_OscConfig(&osc) != HAL_OK)
    {
        /* 没有晶振或晶振不起振：退回内部 HSI/2 x16 = 64 MHz */
        HAL_RCC_DeInit();

        osc.OscillatorType = RCC_OSCILLATORTYPE_HSI;
        osc.HSIState = RCC_HSI_ON;
        osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
        osc.PLL.PLLState = RCC_PLL_ON;
        osc.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
        osc.PLL.PLLMUL = RCC_PLL_MUL16;

        if (HAL_RCC_OscConfig(&osc) != HAL_OK)
        {
            Error_Handler();
        }
    }

    clk.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                    RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV2;   /* I2C1 在 APB1：36 MHz(或 32 MHz) */
    clk.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef gpio = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PC13 LED：先写高再配输出，避免上电闪一下 */
    HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_SET);
    gpio.Pin = LED_PIN;
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LED_PORT, &gpio);

#if APP_USE_KEY_PA0
    /* PA0 按键：内部上拉，按下接地 */
    gpio.Pin = KEY_PIN;
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(KEY_PORT, &gpio);
#endif
}

/**
  * @brief 致命错误：关中断并快闪 PC13。
  */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        LED_TOGGLE();
        for (volatile uint32_t i = 0; i < 250000U; ++i)
        {
            __NOP();
        }
    }
}
