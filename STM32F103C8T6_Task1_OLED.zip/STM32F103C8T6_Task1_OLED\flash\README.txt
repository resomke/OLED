Task1_OLED.hex
  Keil MDK-ARM 编译版（ARM Compiler 6.7），Intel HEX，起始地址 0x08000000。
  本机 Keil 5.24a + DFP 2.2.0 实测：0 Error(s), 0 Warning(s)。
  STM32CubeProgrammer / Keil / FlyMcu 直接选择此文件。

Task1_OLED.bin
  Keil 版原始二进制，烧录时起始地址必须设为 0x08000000。

Task1_OLED_gcc.hex / Task1_OLED_gcc.bin
  GNU Arm GCC 14.2 编译版，功能相同，作为没有 Keil 时的备份。
  GCC 版 Flash 更小（约 17.5 KB），主 HEX 用 Keil 版（约 20.6 KB）。

当前配置：学号 632407030413，姓名 李泓。
芯片：STM32F103C8T6（64 KB Flash，20 KB RAM）
时钟：HSE 8 MHz -> 72 MHz；HSE 不起振时自动回退 HSI 64 MHz
接线：OLED/AHT20 的 SCL=PB6，SDA=PB7，VCC=3.3V，GND=GND
