#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
离线预览 128x64 OLED 的四个页面（不需要硬件）。
它直接读取 Core/Src/oled_font.c 里的点阵，按 oled.c/app.c 的布局重画，
用于检查字库、坐标和滚动窗口是否合理。

用法：
    python tools/preview_ui.py
输出：
    docs/ui_preview.png
"""

from __future__ import annotations

import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
FONT_C = ROOT / "Core" / "Src" / "oled_font.c"
CONFIG_H = ROOT / "Core" / "Inc" / "app_config.h"

W, H = 128, 64


def read_config():
    text = CONFIG_H.read_text(encoding="utf-8")
    student_id = re.search(r'#define\s+STUDENT_ID\s+"([^"]*)"', text).group(1)
    student_name = re.search(r'#define\s+STUDENT_NAME\s+"([^"]*)"', text).group(1)
    marquee = re.search(r'#define\s+MARQUEE_TEXT\s+"([^"]*)"', text).group(1)
    return student_id, student_name, marquee


STUDENT_ID, STUDENT_NAME, MARQUEE_TEXT = read_config()


def parse_fonts():
    text = FONT_C.read_text(encoding="utf-8")

    def parse_ascii(name: str, width: int):
        block = re.search(
            rf"const uint8_t {name}\[95\]\[{width}\] = \{{(.*?)\n\}};",
            text, re.S).group(1)
        rows = re.findall(r"\{([^}]*)\}", block)
        out = []
        for row in rows:
            out.append([int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]{2})", row)])
        return out

    ascii6 = parse_ascii("oled_font6x8", 6)
    ascii8 = parse_ascii("oled_font8x16", 16)

    cn = {}
    for m in re.finditer(r"\{\s*0x([0-9A-Fa-f]{4})U,\s*\{(.*?)\}\s*\}", text, re.S):
        cp = int(m.group(1), 16)
        data = [int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]{2})", m.group(2))]
        if len(data) == 32:
            cn[cp] = data

    return ascii6, ascii8, cn


ASCII6, ASCII8, CN = parse_fonts()


class Canvas:
    def __init__(self):
        self.buf = bytearray(W * H // 8)

    def pixel(self, x: int, y: int, color: int = 1):
        if 0 <= x < W and 0 <= y < H:
            idx = (y // 8) * W + x
            mask = 1 << (y & 7)
            if color:
                self.buf[idx] |= mask
            else:
                self.buf[idx] &= ~mask & 0xFF

    def fill_rect(self, x, y, w, h, color=1):
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                self.pixel(xx, yy, color)

    def hline(self, x, y, w):
        self.fill_rect(x, y, w, 1, 1)

    def rect(self, x, y, w, h):
        self.hline(x, y, w)
        self.hline(x, y + h - 1, w)
        for yy in range(y, y + h):
            self.pixel(x, yy, 1)
            self.pixel(x + w - 1, yy, 1)

    def glyph(self, x, y, w, h, data, sx=1, sy=1):
        for col in range(w):
            for row in range(h):
                bits = data[col + (row // 8) * w]
                if bits & (1 << (row & 7)):
                    self.fill_rect(x + col * sx, y + row * sy, sx, sy, 1)

    def text(self, x, y, s, font):
        cx = x
        for ch in s:
            cp = ord(ch)
            if cp == 10:
                cx = x
                y += 8 if font == "6x8" else 16
                continue
            if cp < 128:
                if font == "6x8":
                    data, w, h = ASCII6[cp - 32], 6, 8
                else:
                    data, w, h = ASCII8[cp - 32], 8, 16
                self.glyph(cx, y, w, h, data)
                cx += w
            else:
                data = CN.get(cp)
                if data:
                    self.glyph(cx, y, 16, 16, data)
                cx += 16

    def text_scaled(self, x, y, s, sx, sy):
        cx = x
        for ch in s:
            cp = ord(ch)
            if cp < 128:
                data, w, h = ASCII8[cp - 32], 8, 16
                self.glyph(cx, y, w, h, data, sx, sy)
                cx += w * sx
            else:
                data = CN.get(cp)
                if data:
                    self.glyph(cx, y, 16, 16, data, sx, sy)
                cx += 16 * sx

    def text_width(self, s, font):
        total = 0
        for ch in s:
            if ord(ch) < 128:
                total += 6 if font == "6x8" else 8
            else:
                total += 16
        return total

    def center(self, y, s, font):
        self.text(max(0, (W - self.text_width(s, font)) // 2), y, s, font)

    def image(self):
        img = Image.new("1", (W, H), 0)
        for y in range(H):
            for x in range(W):
                if self.buf[(y // 8) * W + x] & (1 << (y & 7)):
                    img.putpixel((x, y), 1)
        return img


def page_info():
    c = Canvas()
    c.text(0, 1, "STUDENT ID", "6x8")
    c.text(104, 1, "1/4", "6x8")

    if len(STUDENT_ID) <= 8:
        width = len(STUDENT_ID) * 16
        c.text_scaled((W - width) // 2, 12, STUDENT_ID, 2, 2)
        c.center(47, STUDENT_NAME, "16")
    else:
        width = len(STUDENT_ID) * 8
        c.text(max(0, (W - width) // 2), 14, STUDENT_ID, "8x16")
        c.text(0, 36, "姓名", "16")
        c.text(40, 36, STUDENT_NAME, "16")
        c.text(0, 56, "CQJTU  IOT205", "6x8")
    return c.image()


def page_sensor():
    c = Canvas()
    c.text(0, 1, "AHT20", "6x8")
    c.text(104, 1, "2/4", "6x8")
    c.text(0, 14, "温度", "16")
    c.rect(34, 12, 94, 20)
    c.text(38, 14, "25.6", "8x16")
    c.text(38 + 4 * 8 + 1, 14, "℃", "16")
    c.text(0, 36, "湿度", "16")
    c.rect(34, 34, 94, 20)
    c.text(38, 36, "48.2", "8x16")
    c.text(38 + 4 * 8 + 1, 36, "%", "8x16")
    c.text(0, 56, "CRC OK", "6x8")
    c.text(76, 56, "AHT20", "6x8")
    return c.image()


def page_scroll(offset=96):
    c = Canvas()
    c.text(0, 1, "MARQUEE", "6x8")
    c.text(104, 1, "3/4", "6x8")
    c.hline(0, 10, 128)
    c.hline(0, 34, 128)
    c.center(40, "重庆交通大学", "16")
    c.text(0, 56, "I2C 400kHz", "6x8")
    text = MARQUEE_TEXT
    width = c.text_width(text, "16")
    x = W - offset
    c.text(x, 16, text, "16")
    c.text(x + width + 32, 16, text, "16")
    return c.image()


def page_hw():
    c = Canvas()
    c.center(12, "重庆交通大学", "16")
    c.center(38, "物联网205实训室", "16")
    return c.image()


def main():
    pages = [page_info(), page_sensor(), page_scroll(), page_hw()]
    labels = ["1/4 学号 + 姓名", "2/4 AHT20 温湿度",
              "3/4 长文本软件跑马灯", "4/4 SSD1306 硬件滚动"]
    scale = 4
    margin = 24
    gap = 24
    label_h = 28
    sheet_w = margin * 2 + len(pages) * W * scale + (len(pages) - 1) * gap
    sheet_h = margin * 2 + H * scale + label_h

    sheet = Image.new("RGB", (sheet_w, sheet_h), (18, 20, 26))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype(r"C:\Windows\Fonts\simhei.ttf", 15)

    for i, (page, label) in enumerate(zip(pages, labels)):
        x = margin + i * (W * scale + gap)
        y = margin
        # 简易 OLED 边框
        draw.rounded_rectangle((x - 6, y - 6, x + W * scale + 6, y + H * scale + 6),
                               radius=8, fill=(8, 9, 12), outline=(70, 74, 86), width=2)
        big = page.convert("RGB").resize((W * scale, H * scale), Image.NEAREST)
        # 黑底白像素
        big = big.point(lambda p: 255 if p else 0).convert("RGB")
        sheet.paste(big, (x, y))
        draw.text((x, y + H * scale + 8), label, font=font, fill=(210, 214, 224))

    out = ROOT / "docs" / "ui_preview.png"
    sheet.save(out)
    print(f"written {out}")


if __name__ == "__main__":
    main()
