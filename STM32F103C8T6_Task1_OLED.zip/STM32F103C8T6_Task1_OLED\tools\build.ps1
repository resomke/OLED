# Build Task1_OLED with GNU Arm Embedded Toolchain.
# Usage:
#   powershell -ExecutionPolicy Bypass -File tools\build.ps1
#   powershell -ExecutionPolicy Bypass -File tools\build.ps1 -Toolchain "D:\gcc-arm\bin"

param(
    [string]$Toolchain = "C:\Program Files (x86)\Arm GNU Toolchain arm-none-eabi\14.2 rel1\bin"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$gcc = Join-Path $Toolchain "arm-none-eabi-gcc.exe"
if (-not (Test-Path $gcc)) {
    $cmd = Get-Command arm-none-eabi-gcc.exe -ErrorAction SilentlyContinue
    if ($cmd) {
        $Toolchain = Split-Path -Parent $cmd.Source
        $gcc = $cmd.Source
    } else {
        throw "arm-none-eabi-gcc.exe not found. Install GNU Arm Embedded Toolchain or pass -Toolchain <bin dir>."
    }
}

$objcopy = Join-Path $Toolchain "arm-none-eabi-objcopy.exe"
$size = Join-Path $Toolchain "arm-none-eabi-size.exe"

New-Item -ItemType Directory -Force -Path build, flash | Out-Null

$sources = @(
    "Startup\startup_stm32f103xb.s",
    "Core\Src\main.c",
    "Core\Src\app.c",
    "Core\Src\oled.c",
    "Core\Src\oled_font.c",
    "Core\Src\aht20.c",
    "Core\Src\bsp_i2c.c",
    "Core\Src\bsp_uart.c",
    "Core\Src\syscalls.c",
    "Core\Src\stm32f1xx_it.c",
    "Core\Src\stm32f1xx_hal_msp.c",
    "Core\Src\system_stm32f1xx.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_cortex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_dma.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_flash.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_flash_ex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_gpio.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_i2c.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_pwr.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_rcc.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_rcc_ex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_uart.c"
)

$cflags = @(
    "-mcpu=cortex-m3",
    "-mthumb",
    "-mfloat-abi=soft",
    "-std=gnu11",
    "-Os",
    "-g3",
    "-Wall",
    "-Wextra",
    "-Wno-unused-parameter",
    "-ffunction-sections",
    "-fdata-sections",
    "-DUSE_HAL_DRIVER",
    "-DSTM32F103xB",
    "-ICore\Inc",
    "-IDrivers\STM32F1xx_HAL_Driver\Inc",
    "-IDrivers\STM32F1xx_HAL_Driver\Inc\Legacy",
    "-IDrivers\CMSIS\Device\ST\STM32F1xx\Include",
    "-IDrivers\CMSIS\Include"
)

$ldflags = @(
    "-mcpu=cortex-m3",
    "-mthumb",
    "-mfloat-abi=soft",
    "-T", "LD\STM32F103C8Tx_FLASH.ld",
    "-Wl,--gc-sections",
    "-Wl,--print-memory-usage",
    "-Wl,-Map=build\Task1_OLED.map",
    "--specs=nano.specs",
    "-Wl,--no-warn-rwx-segments",
    "-lm"
)

Write-Host "==> Compiling and linking..."
& $gcc @cflags @sources @ldflags -o "build\Task1_OLED.elf"
if ($LASTEXITCODE -ne 0) { throw "gcc failed with exit code $LASTEXITCODE" }

Write-Host "==> Generating HEX/BIN..."
& $objcopy -O ihex "build\Task1_OLED.elf" "flash\Task1_OLED_gcc.hex"
if ($LASTEXITCODE -ne 0) { throw "objcopy hex failed" }
& $objcopy -O binary "build\Task1_OLED.elf" "flash\Task1_OLED_gcc.bin"
if ($LASTEXITCODE -ne 0) { throw "objcopy bin failed" }

Write-Host "==> Size:"
& $size "build\Task1_OLED.elf"

Write-Host ""
Write-Host "Done:"
Write-Host "  build\Task1_OLED.elf"
Write-Host "  build\Task1_OLED.map"
Write-Host "  flash\Task1_OLED_gcc.hex"
Write-Host "  flash\Task1_OLED_gcc.bin"
