# STM32F103C8T6 任务一：OLED 屏显 + AHT20 温湿度

> 目标芯片：STM32F103C8T6（Blue Pill / 最小系统板，64 KB Flash，20 KB RAM）  
> 屏幕：0.96 寸 128×64 I2C OLED（SSD1306，地址 0x3C 或 0x3D）  
> 传感器：AHT20（I2C 地址 0x38）  
> 开发方式：STM32 HAL 库，Keil MDK-ARM（AC6）工程 + GNU Arm GCC 工程  
> 当前固件：`flash/Task1_OLED.hex`（本机 Keil AC6 实测编译版），可直接用 ST-Link 烧录；  
> GCC 编译版另存为 `flash/Task1_OLED_gcc.hex` / `.bin`

---

## 1. 已经实现了什么

对应任务一的三个要求：

| 页面 | 内容 | 停留时间 |
|---|---|---|
| 1/4 | 学号 + 姓名（8 位自动放大 2 倍；9~12 位用 8×16 居中 + 姓名标签排版） | 4 s |
| 2/4 | AHT20 温度、湿度，2 s 更新一次，带 CRC 状态 | 6 s |
| 3/4 | 长字符串软件跑马灯：`天不生我EDG，VCTCN万古如长夜` | 12 s |
| 4/4 | SSD1306 **硬件水平滚动**演示（附加，0x26/0x27/0x2F） | 8 s |

另外还做了：

- OLED 地址自动探测：0x3C / 0x3D 都可以；
- I2C 总线死锁恢复：连续 3 次失败后自动 DeInit → 手动 9 个 SCL → STOP → Init；
- 上电 HSE 8 MHz × 9 = 72 MHz；如果晶振不起振，自动回退 HSI/2 × 16 = 64 MHz；
- PA0 按键手动切页（PA0 接 GND，内部上拉；不接也能自动轮播）；
- PC13 板载 LED 500 ms 心跳；
- USART1（PA9/PA10，115200）输出启动信息、OLED 地址、AHT20 温湿度和错误码；
- 全屏 1 KB 显存 + 局部页刷新：跑马灯只刷 page2/page3，I2C 占用更低。

![四个页面的离线预览](docs/ui_preview.png)

> 上图是用 `tools/preview_ui.py` 直接读取 `oled_font.c` 点阵生成的离线预览，不是实物拍照。实物是黑底白字。

---

## 2. 接线

![接线图](docs/wiring.png)

| STM32F103C8T6 | OLED | AHT20 | 说明 |
|---|---|---|---|
| 3.3V | VCC | VCC | 必须 3.3 V，不要接 5 V |
| GND | GND | GND | 必须共地 |
| PB6 | SCL | SCL | I2C1 SCL，400 kHz |
| PB7 | SDA | SDA | I2C1 SDA，400 kHz |
| PA9 | — | — | 可选：USART1 TX → USB-TTL RX |
| PA10 | — | — | 可选：USART1 RX → USB-TTL TX |
| PA0 | — | — | 可选：按键到 GND，手动切页 |
| PC13 | — | — | 板载 LED，心跳指示 |

注意事项：

1. OLED 和 AHT20 模块一般自带上拉电阻；如果模块没有，SCL、SDA 各接一个 4.7 kΩ 到 3.3 V。
2. 杜邦线尽量短，电源和地一定要共地；I2C 在长杜邦线上 400 kHz 容易失败，可以先降到 100 kHz 排查。
3. 有的 OLED 模块丝印是 `VCC/GND/SCL/SDA`，有的顺序是 `GND/VCC/SCL/SDA`，以模块丝印为准。
4. 烧录时 BOOT0 = 0，复位后从 Flash 启动。

---

## 3. 直接烧录

### 方式 A：STM32CubeProgrammer + ST-Link（推荐）

1. ST-Link 与板子连接：`SWDIO → PA13`、`SWCLK → PA14`、`GND → GND`、`3.3V → 3.3V`（如果板子已单独供电，可不接 3.3V）。
2. BOOT0 跳线接 0，按一下复位。
3. 打开 STM32CubeProgrammer，选择 `ST-LINK`，点击 Connect。
4. 打开 `flash/Task1_OLED.hex`，点击 Download。
5. 断电重启或按复位，OLED 应显示启动画面，然后进入 1/4 页。

命令行方式：

```powershell
STM32_Programmer_CLI.exe -c port=SWD -w flash\Task1_OLED.hex -v -rst
```

### 方式 B：Keil MDK-ARM

1. 安装 Keil MDK5、`Keil.STM32F1xx_DFP` 设备包和 ARM Compiler 6。
2. 打开 `MDK-ARM/Task1_OLED.uvprojx`。
3. `Options for Target → Debug` 选择 `ST-Link Debugger`，Port 选 `SW`。
4. `Options for Target → Flash Download` 勾选 `Reset and Run`。
5. 编译（F7），下载（F8）。

工程已经配置好：

- Device：`STM32F103C8`
- Flash：64 KB（0x08000000–0x0800FFFF）
- RAM：20 KB（0x20000000–0x20004FFF）
- 输出：`MDK-ARM/Objects/Task1_OLED.hex`
- C 语言标准：C11（AC6）

> 本机已用 **Keil 5.24a + ARM Compiler 6.7 + Keil.STM32F1xx_DFP 2.2.0** 实测编译：  
> `0 Error(s), 0 Warning(s)`，生成 `MDK-ARM/Objects/Task1_OLED.hex`。  
> 如果你的 Pack 不是 2.2.0，Keil 可能会提示切换版本；安装 2.2.0 或在工程里选择已安装版本即可。  
> 如果打开工程时提示安装 **CMSIS / MDK-Middleware / GUI** 组件：本工程不使用 RTE，CMSIS 和 HAL 源文件都已放在 `Drivers/` 下，直接点 **Cancel / 不安装** 也能正常编译。  


> 如果中文注释乱码，把 Keil 的 Encoding 设为 UTF-8。

### 方式 C：串口 ISP（没有 ST-Link 时）

1. BOOT0 = 1，BOOT1 = 0，复位。
2. USB-TTL：PA9 → RX，PA10 → TX，GND → GND。
3. 用 FlyMcu / STM32CubeProgrammer 的 UART 模式，选择 `flash/Task1_OLED.hex`，波特率 115200。
4. 烧录完成后 BOOT0 改回 0，复位运行。

### 方式 D：GNU Arm GCC 重新编译

没有 Keil 时也可以用 GCC 编译：

```powershell
powershell -ExecutionPolicy Bypass -File tools\build.ps1
```

默认工具链路径：

```text
C:\Program Files (x86)\Arm GNU Toolchain arm-none-eabi\14.2 rel1\bin
```

如果安装在其他位置：

```powershell
powershell -ExecutionPolicy Bypass -File tools\build.ps1 -Toolchain "D:\gcc-arm\bin"
```

输出：

```text
build/Task1_OLED.elf
build/Task1_OLED.map
flash/Task1_OLED_gcc.hex
flash/Task1_OLED_gcc.bin
```

当前固件大小：

```text
Keil AC6 版本（flash/Task1_OLED.hex）：
  Code = 16078 B, RO-data = 4510 B, RW-data = 16 B
  FLASH 约 20608 B / 64 KB  (31.4%)
  RAM   = 4352 B / 20 KB   (21.2%)，其中 Keil 启动文件预留 2 KB 栈

GCC 版本（flash/Task1_OLED_gcc.hex）：
  FLASH = 17492 B / 64 KB  (26.7%)
  RAM   = 4872 B / 20 KB   (23.8%)，链接脚本预留 2 KB 栈
```

两个版本功能完全相同；主 HEX 用 Keil 版本，GCC 版本作为备份/没有 Keil 时使用。

---

## 4. 改学号 / 姓名 / 滚动文字

所有个性化内容都在 `Core/Inc/app_config.h`：

```c
#define STUDENT_ID      "632407030413"
#define STUDENT_NAME    "李泓"
#define MARQUEE_TEXT    "天不生我EDG，VCTCN万古如长夜"
```

改完后：

1. 如果只改学号（数字）或英文，直接重新编译即可。
2. 如果改了中文姓名/中文句子，需要重新生成 16×16 汉字字库：

```powershell
python -m pip install -r tools\requirements.txt
python tools\gen_font.py
```

3. 再编译、烧录。

为什么需要重新生成字库？因为 64 KB Flash 放不下完整 GB2312 字库（约 260 KB）。本工程只把源代码字符串里出现过的汉字收进 `oled_font.c`，当前一共 56 个汉字/标点，既够用又省 Flash。

> 如果电脑上没有 Python/Pillow，可以把学号和姓名发给我，我重新生成一个包含你姓名的 HEX。  
> 也可以把 `STUDENT_NAME` 改成英文/拼音，直接编译，不需要改字库。

---

## 5. 页面操作

- 上电默认第 1 页（学号姓名）。
- 每页自动停留，时间到了自动切下一页。
- 按 PA0（接 GND）立即切下一页；松手后 20 ms 消抖，长按不会连续切页。
- AHT20 页面每 2 s 采样一次；如果传感器没接，会显示“未检测到传感器 / 请检查 SDA/SCL”，不会死机。
- 第 4 页是 SSD1306 内部硬件滚动，整屏内容会移动；离开该页会自动发 `0x2E` 停止滚动。  
  如果方向相反，把 `app.c` 里 `oled_hw_scroll_start(true, ...)` 的 `true` 改成 `false` 即可。

---

## 6. 工程结构

```text
STM32F103C8T6_Task1_OLED/
├─ Core/
│  ├─ Inc/
│  │  ├─ app_config.h          # 学号、姓名、滚动文字、页面时间、I2C 地址
│  │  ├─ main.h
│  │  ├─ board.h               # LED/按键引脚
│  │  ├─ oled.h                # SSD1306 驱动接口
│  │  ├─ oled_font.h           # 字库声明
│  │  ├─ aht20.h               # AHT20 接口
│  │  ├─ bsp_i2c.h
│  │  ├─ bsp_uart.h
│  │  └─ stm32f1xx_hal_conf.h  # 只开必要 HAL 模块
│  └─ Src/
│     ├─ main.c                # HAL_Init、72/64 MHz 时钟、GPIO
│     ├─ app.c                 # 四个页面、自动轮播、按键、错误恢复
│     ├─ oled.c                # 1 KB 显存、画点/矩形/文字、局刷、硬件滚动
│     ├─ oled_font.c           # 自动生成的点阵字库（不要手改）
│     ├─ aht20.c               # AHT20 初始化、触发、CRC、温湿度换算
│     ├─ bsp_i2c.c             # I2C1 400 kHz、总线恢复、地址扫描
│     ├─ bsp_uart.c            # 115200 日志（不依赖 printf）
│     ├─ stm32f1xx_hal_msp.c   # PB6/PB7、PA9/PA10 底层初始化
│     ├─ stm32f1xx_it.c        # SysTick
│     ├─ system_stm32f1xx.c
│     └─ syscalls.c            # GCC newlib 最小桩
├─ Drivers/
│  ├─ CMSIS/                   # Cortex-M3 内核头文件、STM32F1 设备头文件
│  └─ STM32F1xx_HAL_Driver/    # ST HAL 库
├─ MDK-ARM/
│  ├─ Task1_OLED.uvprojx       # Keil 工程
│  └─ startup_stm32f103xb.s    # Keil/ARMASM 启动文件
├─ Startup/startup_stm32f103xb.s # GCC 启动文件
├─ LD/STM32F103C8Tx_FLASH.ld   # GCC 链接脚本（64 KB Flash / 20 KB RAM）
├─ build/                      # elf/map/编译日志
├─ flash/
│  ├─ Task1_OLED.hex           # 可直接烧录（Keil AC6 编译版）
│  ├─ Task1_OLED.bin           # 0x08000000 起始的原始 bin（Keil 版）
│  ├─ Task1_OLED_gcc.hex       # GCC 编译版
│  └─ Task1_OLED_gcc.bin       # GCC 版 bin
├─ tools/
│  ├─ gen_font.py              # 扫描源文件中的中文，生成 16×16 点阵
│  ├─ build.ps1                # GCC 一键编译
│  ├─ preview_ui.py            # 离线生成四页预览图
│  └─ make_wiring.py           # 生成接线图
└─ docs/
   ├─ wiring.png
   └─ ui_preview.png
```

---

## 7. 关键原理（可直接写进实验报告）

### 7.1 I2C 协议

I2C 是两线制同步串行总线：

- **SCL**：时钟线，主机产生；
- **SDA**：数据线，双向；
- 两根线都是 **开漏输出**，必须接上拉电阻，所以 idle 时都是高电平；
- **起始条件**：SCL 高电平期间，SDA 由高变低；
- **停止条件**：SCL 高电平期间，SDA 由低变高；
- 数据在 SCL 低电平期间改变，在 SCL 高电平期间被采样；
- 每字节 8 bit，高位先发，第 9 个时钟是 ACK/NACK；
- 7 位地址 + 1 位读写位：OLED 写地址 `0x3C << 1 = 0x78`，AHT20 写地址 `0x38 << 1 = 0x70`。

本工程用 STM32F1 的硬件 I2C1：

```c
hi2c1.Instance = I2C1;
hi2c1.Init.ClockSpeed = 400000;
hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
```

PB6/PB7 配置为 `GPIO_MODE_AF_OD`（复用开漏）。如果从机在传输中途掉电，可能一直拉低 SDA，主机就会 `BUSY`。本工程在初始化前和连续 3 次错误后做总线恢复：

```text
HAL_I2C_DeInit
→ PB6/PB7 当普通开漏 GPIO
→ SDA 高，SCL 打 9 个时钟
→ 手动产生 STOP
→ HAL_I2C_Init
```

### 7.2 SSD1306 显存与刷屏

SSD1306 的 GDDRAM 是 128×64 bit，组织成 8 个 page，每个 page 8 行：

```text
page0: y=0..7
page1: y=8..15
...
page7: y=56..63
```

每个字节代表一列 8 个纵向像素，**LSB 在上**。所以 1 KB 显存正好对应整屏：

```c
uint8_t oled_buffer[128 * 8];
/* index = page * 128 + x */
```

写显存时先发控制字节 `0x00` 表示后面是命令，再发 `0x40` 表示后面是数据：

```text
0x21 0x00 0x7F  设置列地址 0..127
0x22 0x00 0x07  设置页地址 0..7
0x40 + 1024 字节 连续写 GDDRAM
```

初始化里比较关键的几条：

```text
0xAE            display off
0x8D 0x14       charge pump on（0.96 寸模块必须开）
0x20 0x00       水平寻址模式
0xA1 / 0xC8     左右/上下方向
0xDA 0x12       COM 引脚配置
0xAF            display on
```

### 7.3 汉字点阵与 UTF-8

一个 16×16 汉字需要 32 字节：

```text
前 16 字节：上半部分（page0），16 列
后 16 字节：下半部分（page1），16 列
每个字节：纵向 8 像素，bit0 在最上面
```

例如“温”字的点阵在 `Core/Src/oled_font.c` 里就是 32 个十六进制数。`oled_draw_text()` 会先按 UTF-8 解码：

- 1 字节：ASCII，查 8×16 或 6×8 字库；
- 3 字节：常用汉字，查 16×16 字库；
- 查表用二分查找（字库按 Unicode 码点升序排列）。

字库不是完整的，只包含源代码字符串里出现过的字符。这样 64 KB Flash 才放得下。

### 7.4 AHT20 温湿度

AHT20 的流程：

```text
上电等待 40 ms
读状态字节
若 bit3=0：发 0xBE 0x08 0x00，等待 10 ms
触发测量：0xAC 0x33 0x00
等待 80 ms
读 7 字节：status + hum(20bit) + temp(20bit) + CRC
```

数据换算：

```c
humidity_raw = (data[1] << 12) | (data[2] << 4) | (data[3] >> 4);
temp_raw     = ((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5];

humidity    = humidity_raw * 100.0f / 1048576.0f;       // %RH
temperature = temp_raw * 200.0f / 1048576.0f - 50.0f;   // ℃
```

CRC8 多项式 `0x31`，初值 `0xFF`，对前 6 字节校验，和第 7 字节比较。CRC 不对时仍然显示数据，但状态栏显示 `CRC ERR`，方便排查模块质量。

### 7.5 两种滚动方式的区别

- **第 3 页：软件跑马灯**  
  在 1 KB 显存里把文字整体左移，每次只刷新 page2/page3（256 字节）。优点是可以滚动任意长度的字符串，不受 128 列 GDDRAM 限制；缺点是占一点 CPU 和 I2C 带宽。

- **第 4 页：SSD1306 硬件水平滚动**  
  用 SSD1306 内部的滚动引擎：

  ```text
  0x2E             停止滚动
  0x27 0x00 0x00 0x00 0x07 0x00 0xFF   向左滚动，page0..7
  0x2F             启动滚动
  ```

  优点是不需要CPU逐帧刷显存；缺点是 SSD1306 的滚动是在 128 列 GDDRAM 内循环，超过 128 像素的长字符串会被截断/绕回。所以长句用第 3 页，硬件滚动作为原理演示放在第 4 页。

> 题目里“最好使用硬件刷屏模式”可以两种理解：  
> 1）用硬件 I2C 外设 + 整屏显存一次性 burst 写入（本工程 `oled_refresh()` 就是）；  
> 2）用 SSD1306 内置的硬件滚动命令（本工程第 4 页）。  
> 两种都实现了，报告里可以分别说明。

---

## 8. 常见问题

### OLED 完全不亮

1. 先量 OLED 的 VCC 是否有 3.3 V，GND 是否共地。
2. 确认 SCL 接 PB6、SDA 接 PB7，不要接反。
3. 用 USART1 看日志，正常会打印：

   ```text
   OLED: found at 0x3C
   ```

   如果打印 `NOT FOUND`，检查地址和接线。
4. 有的模块地址是 0x3D，代码会自动探测；如果都不行，用 `bsp_i2c_scan()` 扫一下。
5. 模块没有上拉电阻时，SCL/SDA 各加 4.7 kΩ 到 3.3 V。

### AHT20 显示“未检测到传感器”

1. AHT20 的 VCC 必须是 3.3 V，GND 共地。
2. 地址固定 0x38；SCL/SDA 与 OLED 并联。
3. 上电后至少等 40 ms；本工程 `aht20_init()` 里已经 `HAL_Delay(40)`。
4. 如果 CRC 一直 ERR，但温湿度有变化，可能是模块 CRC 未实现，不影响读数。
5. 用串口看日志：

   ```text
   AHT20: init OK
   AHT20: T=25.6 C, RH=48.2 %, CRC=OK
   ```

### Keil 编译/下载问题

- `cannot open source input file "stm32f1xx_hal.h"`：检查 `Options for Target → C/C++ → Include Paths` 是否包含 `..\Drivers\STM32F1xx_HAL_Driver\Inc` 等 5 个路径。
- `Device not found`：安装 `Keil.STM32F1xx_DFP` 设备包，或把 Device 改成 `STM32F103C8`。
- `Cannot access target`：检查 SWDIO/SWCLK/GND，BOOT0=0，按复位再连接；ST-Link 的 NRST 可接可不接。
- 中文乱码：Keil `Edit → Configuration → Encoding` 设为 UTF-8；源文件本身是 UTF-8。
- 只装了 AC5：工程默认 AC6；可以在 `Options for Target → Target → ARM Compiler` 里切换，但建议装 AC6。

### 串口乱码

- 波特率 115200，8 数据位，1 停止位，无校验；
- PA9 接 USB-TTL 的 RX，PA10 接 TX，GND 必须共地；
- 不要接 5 V TTL 电平。

### I2C 偶发失败

- 杜邦线太长、接触不良、上拉太弱都会导致 400 kHz 失败；
- 可以先把 `hi2c1.Init.ClockSpeed` 改成 `100000` 测试；
- 本工程有总线恢复，但频繁失败还是要先查硬件。

---

## 9. 用 CubeMX 复现（为任务三做准备）

如果老师要求用 CubeMX 建工程，按下面配置：

| 项目 | 设置 |
|---|---|
| MCU | STM32F103C8Tx |
| RCC | HSE：Crystal/Ceramic Resonator |
| Clock | HSE 8 MHz，PLL ×9，SYSCLK 72 MHz，APB1 /2 = 36 MHz，APB2 /1 = 72 MHz |
| I2C1 | I2C，400 kHz，PB6=SCL，PB7=SDA |
| USART1 | Asynchronous，115200，8N1，PA9=TX，PA10=RX |
| GPIO | PC13 输出（LED），PA0 输入上拉（按键） |
| Project | MDK-ARM，ARM Compiler 6，Copy only necessary library files |

生成后，把本工程的 `Core/Src/oled.c`、`oled_font.c`、`aht20.c`、`bsp_i2c.c`、`bsp_uart.c`、`app.c` 和对应头文件加进去，把 `main.c` 里的 `while (1)` 换成 `app_run()` 即可。  
任务三的 U8G2 移植可以在本工程基础上替换 `oled.c` 的绘图部分，I2C/AHT20/页面框架都可以复用。

---

## 10. 附：Keil 虚拟逻辑分析仪能采 I2C 吗？

**结论：不能可靠采集真实的 I2C 波形。**

Keil 的 Logic Analyzer 是通过 SWD/JTAG 调试访问来采样变量或外设寄存器的，采样率受调试接口和 IDE 刷新速度限制，通常是毫秒级甚至更慢。而 I2C 400 kHz 时一个 bit 只有 2.5 µs，一个完整字节（含 ACK）约 22.5 µs。用 Keil 的 Logic Analyzer 看 `GPIOB->IDR` 或 SDA 变量，会出现：

- 采样点严重欠采样，波形被“抽稀”成几个不规则跳变；
- 看起来像方波，但无法对应真实的 START/ADDR/ACK；
- 调试器暂停/单步时总线可能已经超时，波形更不真实；
- 如果引脚配置为 AF_OD，GPIO 输出寄存器并不等于总线实际电平，看到的值也可能是错的。

因此它只能用来观察“程序变量什么时候变”，不能替代示波器/逻辑分析仪做协议解码。

**可替代的方法：**

1. **USB 逻辑分析仪（推荐）**：Saleae Logic 16 / 兼容 24 MHz 采样，接 SCL、SDA、GND，用 PulseView 或 Saleae 软件加 I2C 解码器，能直接看到地址、读写位、ACK、数据。
2. **示波器**：双通道分别看 SCL/SDA，触发 SDA 下降沿（START），用余辉/滚动模式看时序；适合看上升沿、上拉、总线死锁。
3. **STM32 定时器 + DMA 边沿捕获**：用输入捕获记录 SCL/SDA 边沿时间戳，再串口输出，适合没有逻辑分析仪时做定量测量。
4. **GPIO 打点法**：在软件 I2C 的每个 bit 翻转一个空闲 GPIO，用逻辑分析仪/示波器看这个“调试脉冲”，间接判断代码执行到哪一步；但这不是真实总线波形。
5. **降低速率**：把 I2C 降到 10 kHz 以下，Keil 的采样有可能看到粗略的电平变化，但仍然不能做完整协议解码，只适合演示。

报告里可以写：Keil 虚拟逻辑分析仪适合看变量/寄存器级调试，真实 I2C 时序测量必须用外部逻辑分析仪或示波器。

---

## 11. 说明

- 当前已配置为学号 `632407030413`、姓名 `李泓`；如需修改，按第 4 节操作。
- 字库是从 Windows 宋体（汉字/8×16 ASCII）和 Consolas（6×8 小字）生成的子集，仅用于课程作业，不要用于商业再分发。
- HAL/CMSIS 版权归 STMicroelectronics / ARM，许可证文件已保留在 `Drivers/` 下。
- 任务二（示波器/逻辑分析仪测量）和任务三（U8G2 移植、头像/动态图案）可以在这个工程基础上继续做。
