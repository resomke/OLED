/**
  ******************************************************************************
  * @file    main.h
  * @brief   全局入口声明。
  ******************************************************************************
  */
#ifndef MAIN_H
#define MAIN_H

#include "stm32f1xx_hal.h"

void SystemClock_Config(void);
void Error_Handler(void);

#endif /* MAIN_H */
