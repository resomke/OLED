/**
  ******************************************************************************
  * @file    oled.h
  * @brief   SSD1306 128x64 I2C OLED 驱动，1 KB 显存 + 局刷 + 硬件滚动。
  ******************************************************************************
  */
#ifndef OLED_H
#define OLED_H

#include <stdbool.h>
#include <stdint.h>

#define OLED_WIDTH              128U
#define OLED_HEIGHT             64U
#define OLED_PAGES              (OLED_HEIGHT / 8U)
#define OLED_BUFFER_SIZE        (OLED_WIDTH * OLED_PAGES)

typedef enum
{
    OLED_FONT_6X8 = 0,
    OLED_FONT_8X16,
    OLED_FONT_16X16
} oled_font_t;

/* 探测 0x3C/0x3D 并写初始化命令。不清屏。 */
bool oled_init(void);

/* 显存操作 */
void oled_clear(void);
void oled_draw_pixel(int16_t x, int16_t y, uint8_t color);
void oled_fill_rect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color);
void oled_draw_hline(int16_t x, int16_t y, int16_t w, uint8_t color);
void oled_draw_vline(int16_t x, int16_t y, int16_t h, uint8_t color);
void oled_draw_rect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color);

/* 整屏/局刷（页号 0..7） */
bool oled_refresh(void);
bool oled_refresh_pages(uint8_t first_page, uint8_t last_page);

/* UTF-8 文本绘制。中文字符自动使用 16x16 字库。 */
void oled_draw_text(int16_t x, int16_t y, const char *utf8, oled_font_t font);
void oled_draw_text_center(int16_t y, const char *utf8, oled_font_t font);
void oled_draw_text_scaled(int16_t x, int16_t y, const char *utf8,
                           oled_font_t font, uint8_t sx, uint8_t sy);
uint16_t oled_text_width(const char *utf8, oled_font_t font);
uint16_t oled_text_width_scaled(const char *utf8, oled_font_t font,
                                uint8_t sx);

/* SSD1306 硬件水平滚动：dir_left=true 时内容向左移动。
 * start_page/end_page 为 0..7；interval 0x00 最快，0x07 最慢。 */
bool oled_hw_scroll_start(bool dir_left, uint8_t start_page,
                          uint8_t end_page, uint8_t interval);
void oled_hw_scroll_stop(void);

/* 当前实际使用的 OLED 7 位地址；未探测到时为 0 */
uint8_t oled_address(void);

#endif /* OLED_H */
